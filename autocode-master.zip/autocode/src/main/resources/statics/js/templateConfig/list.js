

var vm = new Vue({
    el:'#autocodeapp',
    data:{
        showList: true,
        title: null,
        templateConfig:{
        	type : 0,
        	templateName:null,
        	templateId:null,
        	templateFileName:null,
        	templateType:null,
        	templatePath:null,
        	templateContent:null
        }
    },
    methods: {
        addTemplate: function(){
            vm.showList = false;
            vm.title = "新增模板";
            vm.templateConfig = {type:0};
        },
        addTemplateDetail: function(){
        	 var templateId = getTemplateId();
             if(templateId == null){
                 return ;
             }
             
            vm.showList = false;
            vm.title = "新增模板文件";
            vm.templateConfig = {type:1,"templateId":templateId};
        },
        update: function () {
            var id = getTemplateConfigId();
            if(id == null){
                return ;
            }
            if(isTemplateFile(id)){
            	id = id.substring(1,id.length);
            	 $.get(baseURL + "/templateConfigDetail/toModify.htm?id="+ id, function(r){
                     vm.showList = false;
                     vm.title = "修改模板文件";
                     vm.templateConfig = r.templateConfig;
                     vm.templateConfig["type"]=1;
                 });
            }else{
            	 $.get(baseURL + "/templateConfig/toModify.htm?id="+id, function(r){
                     vm.showList = false;
                     vm.title = "修改模板";
                     
                     vm.templateConfig = r.templateConfig;
                     vm.templateConfig["type"]=0;
                 });
            }
        },
        del: function () {
            var id = getTemplateConfigId();
            if(id == null){
                return ;
            }

            confirm('确定要删除选中的记录？', function(){
            	
            	var url = "";
            	if(isTemplateFile(id)){
                	url = "/templateConfigDetail/delete.htm";
                	id = id.substring(1,id.length);
                }else{
                	url = "/templateConfig/delete.htm";
                }
            	
                $.ajax({
                    type: "POST",
                    url: baseURL + url,
                    data: "id=" + id,
                    success: function(r){
                        if(r.code === 0){
                            alert('操作成功', function(){
                                vm.reload();
                            });
                        }else{
                            alert(r.msg);
                        }
                    }
                });
            });
        },
        saveOrUpdate: function () {
            var url  = "";
            if(vm.templateConfig.type == 0){
            	url = vm.templateConfig.id == null ? "/templateConfig/doAdd.htm" : "/templateConfig/doModify.htm";
            }else{
            	url = vm.templateConfig.id == null ? "/templateConfigDetail/doAdd.htm" : "/templateConfigDetail/doModify.htm";
            }

            $.ajax({
                type: "POST",
                url:  baseURL + url,
                contentType: "application/json",
                data: JSON.stringify(vm.templateConfig),
                success: function(r){
                    if(r.code === 0){
                        alert('操作成功', function(){
                            vm.reload();
                        });
                    }else{
                        alert(r.msg);
                    }
                }
            });
        },
        reload: function () {
            vm.showList = true;
            TemplateConfig.table.refresh();
        },
        viewTemplateFileContent: function(id){
        	
        	$("#templateFileContentLayer").children("iframe").attr("src",baseURL + "/templateConfigDetail/viewContent.htm?id="+id)
        	
			layer.open({
				type: 1,
				skin: 'layui-layer-molv',
				title: "模板内容预览",
				area: ['800px', '400px'],
				shadeClose: false,
				content: jQuery("#templateFileContentLayer"),
				btn: ['关闭']
			});
		},
        validator: function () {
        	return true;
        }
    }
});


var TemplateConfig = {
    id: "templateConfigTable",
    table: null,
    layerIndex: -1
};

/**
 * 初始化表格的列
 */
TemplateConfig.initColumn = function () {
    var columns = [
        {field: 'selectItem', radio: true},
        {title: '模板名称', field: 'name', align: 'center', valign: 'middle', sortable: false,width: '120px'},
        {title: '文件类型', field: 'type', align: 'center', valign: 'middle', sortable: false,width: '30px'},
        {title: '模板路径', field: 'path', align: 'center', valign: 'middle', sortable: false, width: '60px'},
        {title: '查看内容', field: 'parentId', align: 'center', valign: 'middle', sortable: false, width: '30px', formatter: function(item, index){
        	if(item.parentId == 0){
        		return "";
        	}else{
        		
        		var id = item.id.substring(1);
        		return '<a href="#" onclick="vm.viewTemplateFileContent('+ id +')" >预览模板</a>';
        	}
        }}
        ]
    return columns;
};

function isTemplateFile(id){
	 var reg=new RegExp("^s");
     return reg.test(id);
}

function getTemplateConfigId () {
    var selected = $('#templateConfigTable').bootstrapTreeTable('getSelections');
    if (selected.length == 0) {
        alert("请选择一条记录");
        return null;
    } else {
        return selected[0].id;
    }
}

function getTemplateId () {
    var selected = $('#templateConfigTable').bootstrapTreeTable('getSelections');
    if (selected.length == 0) {
        alert("请选择一个模板");
        return null;
    } else {
    	
        var id = selected[0].id;
        
        if(isTemplateFile(id)){
        	alert("请选择一个模板");
            return null;
        }
        return id;
    }
}

$(function () {
    var colunms = TemplateConfig.initColumn();
    var table = new TreeTable(TemplateConfig.id, baseURL + "/templateConfig/listData.htm", colunms);
    table.setExpandColumn(1);
    table.setIdField("id");
    table.setCodeField("id");
    table.setParentCodeField("parentId");
    table.setExpandAll(false);
    table.init();
    TemplateConfig.table = table;
});
