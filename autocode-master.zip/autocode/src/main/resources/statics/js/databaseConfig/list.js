$(function () {
    $("#jqGrid").jqGrid({
        url: baseURL + '/databaseConfig/listData.htm',
        datatype: "json",
        colModel: [			
        	{ label: '类型', name: 'dbType',sortable: false, width: 20 },
            { label: '描述', name: 'dbDesc',sortable: false, width: 50 },
            { label: 'Url', name: 'dbUrl',sortable: false, width: 80 },
            { label: '名称', name: 'dbName', sortable: false, width: 40 },
            { label: '用户名', name: 'dbUsername',sortable: false, width: 20 },
            { label: '密码', name: 'dbPassword',sortable: false, width: 20 },
            { label: '包路径', name: 'defaultPakeage',sortable: false, width: 60 }
        ],
		viewrecords: true,
        height: 385,
        rowNum: 10,
		rowList : [10,30,50],
        rownumbers: true, 
        rownumWidth: 25, 
        autowidth:true,
        multiselect: true,
        pager: "#jqGridPager",
        jsonReader : {
            root: "page.list",
            page: "page.currPage",
            total: "page.totalPage",
            records: "page.totalCount"
        },
        prmNames : {
            page:"page", 
            rows:"limit", 
            order: "order"
        },
        gridComplete:function(){
        	//隐藏grid底部滚动条
        	$("#jqGrid").closest(".ui-jqgrid-bdiv").css({ "overflow-x" : "hidden" }); 
        }
    });
});

var vm = new Vue({
    el:'#autocodeapp',
    data:{
        q:{
        	dbName: null
        },
        showList: true,
        title:null,
        databaseConfig:{
        	dbDesc:null,
        	dbType:null,
        	dbIp:null,
        	dbName:null,
        	dbUsername:null,
        	dbPassword:null,
        	defaultPakeage:null
        }
    },
    methods: {
        query: function () {
            vm.reload();
        },
        add: function(){
            vm.showList = false;
            vm.title = "新增";
            vm.roleList = {};
            vm.databaseConfig = {dbType:"mysql"};
            
        },
        update: function () {
            var id = getSelectedRow();
            if(id == null){
                return ;
            }

            vm.showList = false;
            vm.title = "修改";

            vm.getDatabaseConfig(id);
        },
        del: function () {
            var ids = getSelectedRows();
            if(ids == null){
                return ;
            }

            confirm('确定要删除选中的记录？', function(){
                $.ajax({
                    type: "POST",
                    url: baseURL + "/databaseConfig/delete.htm",
                    contentType: "application/json",
                    data: JSON.stringify(ids),
                    success: function(r){
                        if(r.code == 0){
                            alert('操作成功', function(){
                                vm.reload();
                            });
                        }else{
                            alert(r.msg);
                        }
                    }
                });
            });
        },
        saveOrUpdate: function () {
            var url = vm.databaseConfig.id == null ? "/databaseConfig/doAdd.htm" : "/databaseConfig/doModify.htm";
            $.ajax({
                type: "POST",
                url: baseURL + url,
                contentType: "application/json",
                data: JSON.stringify(vm.databaseConfig),
                success: function(r){
                    if(r.code === 0){
                        alert('操作成功', function(){
                            vm.reload();
                        });
                    }else{
                        alert(r.msg);
                    }
                }
            });
        },
        getDatabaseConfig: function(id){
            $.get(baseURL + "/databaseConfig/toModify.htm?id="+id, function(r){
                vm.databaseConfig = r.databaseConfig;
            });
        },
        reload: function () {
            vm.showList = true;
            var page = $("#jqGrid").jqGrid('getGridParam','page');
            $("#jqGrid").jqGrid('setGridParam',{
                postData:{'jdbcType': vm.q.jdbcType},
                page:page
            }).trigger("reloadGrid");
        }
    }
});