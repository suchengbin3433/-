var treeSetting = {
    data: {
        simpleData: {
            enable: true,
            idKey: "id",
            pIdKey: "pId",
            rootPId: -1
        }
    },
    callback: {
		onClick : function(event, treeId, treeNode) { //点击树节点的回调函数
			var fileName = treeNode.name;
			var filePath = treeNode.desc;
			if(filePath){
				readFile(filePath,fileName);
			}
		}
	},
};
var ztree;

var vm = new Vue({
	el : '#autocodeapp',
	data : {
		q : {
			filePath : ""
		},
		showList : true,
		title : null
	},
	methods : {
		initFileTree: function(){
            //加载菜单树
            $.get(baseURL + "/fileTree.htm?filePath=" + $("#filePath").val(), function(r){
                ztree = $.fn.zTree.init($("#fileTree"), treeSetting, r.treeList);
            })
        },
        exportCode : function() {	// 导出代码
        	 $("#exportForm").submit();
		},
	}
});

$(function () {
	var height = $(document).height() - 70;
	if(height < 200){
		heigth = 200;
	}
	$(".ztree").height(height);
	$("#fileContent").height(height + 10);
	
    vm.initFileTree();
    
});


function readFile(filePath, fileName) {
	$.ajax({
		url : baseURL + "/fileRead.htm",
		data : {
			"filePath" : filePath
		},
		type : "post",
		dataType : "json",
		success : function(result) {
			showFileContent(fileName,result["lines"]);
		},
		error : function() {
			alert("操作异常");
		}
	})
}

function showFileContent(fileName,fileContent){
	var h = $("#fileContent").height();
	if(h < 400){
		h = 400;
	}
	fileContent = fileContent.replace(/</g, '&lt;')
	
	var $iframe = $('<iframe class="test-wrap" src="about:blank" />');
	$iframe.height(h - 10);
	var background = "#fff";
	var themeName = "Eclipse";
	
	$("#fileContent").empty().append($iframe);
	
	$iframe.ready(function(){
				var doc = $iframe[0].contentDocument;
				$iframe.css('background', background);

				doc.write(''
	                + '<link type="text/css" rel="stylesheet" href="' + baseURL + '/plugins/syntaxhighlighter/shCore' + themeName + '.css"/>'
	                + '<style>.syntaxhighlighter {overflow: hidden !important;margin-top:0 !important;} .toolbar{display: none;}</style>'
					+ '<scr' + 'ipt type="text/javascript" src="' + baseURL + '/plugins/syntaxhighlighter/shCore.js"></scr' + 'ipt>'
					+ '<scr' + 'ipt type="text/javascript" src="' + baseURL + '/plugins/syntaxhighlighter/shBrushXml.js"></scr' + 'ipt>'
					+ '<scr' + 'ipt type="text/javascript" src="' + baseURL + '/plugins/syntaxhighlighter/shBrushJava.js"></scr' + 'ipt>'

					+ '<pre type="syntaxhighlighter" class="brush: java;" title="<h2>' + fileName + '</h2>">'
						+ fileContent
					+ '</pre>'
					+ '<scr' + 'ipt type="text/javascript">'
						+ 'SyntaxHighlighter.highlight();'
					+ '</scr' + 'ipt>'
					);
				doc.close();
			});
}