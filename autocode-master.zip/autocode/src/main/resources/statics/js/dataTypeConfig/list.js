$(function () {
    $("#jqGrid").jqGrid({
        url: baseURL + '/dataTypeConfig/listData.htm',
        datatype: "json",
        colModel: [			
			{ label: 'Jdbc数据类型', name: 'jdbcType',index: "jdbc_type",sortable: true, width: 45 },
            { label: 'Java数据类型', name: 'javaType',index: "java_type",sortable: true, width: 45 },
            { label: 'Java数据类型包路径', name: 'javaPackage', sortable: false, width: 80 },
            { label: '数据库类型', name: 'dbType',sortable: false, width: 45 }
        ],
		viewrecords: true,
        height: 385,
        rowNum: 10,
		rowList : [10,30,50],
        rownumbers: true, 
        rownumWidth: 25, 
        autowidth:true,
        multiselect: true,
        pager: "#jqGridPager",
        jsonReader : {
            root: "page.list",
            page: "page.currPage",
            total: "page.totalPage",
            records: "page.totalCount"
        },
        prmNames : {
            page:"page", 
            rows:"limit", 
            order: "order"
        },
        gridComplete:function(){
        	//隐藏grid底部滚动条
        	$("#jqGrid").closest(".ui-jqgrid-bdiv").css({ "overflow-x" : "hidden" }); 
        }
    });
});

var vm = new Vue({
    el:'#autocodeapp',
    data:{
        q:{
        	dbType: null
        },
        showList: true,
        title:null,
        dataTypeConfig:{
        	dbType:null,
        	jdbcType:null,
        	javaType:null,
        	javaPackage:null
        }
    },
    methods: {
        query: function () {
            vm.reload();
        },
        add: function(){
            vm.showList = false;
            vm.title = "新增";
            vm.roleList = {};
            vm.dataTypeConfig = {dbType:"mysql"};
            
        },
        update: function () {
            var id = getSelectedRow();
            if(id == null){
                return ;
            }

            vm.showList = false;
            vm.title = "修改";

            vm.getDataTypeConfig(id);
        },
        del: function () {
            var ids = getSelectedRows();
            if(ids == null){
                return ;
            }

            confirm('确定要删除选中的记录？', function(){
                $.ajax({
                    type: "POST",
                    url: baseURL + "/dataTypeConfig/delete.htm",
                    contentType: "application/json",
                    data: JSON.stringify(ids),
                    success: function(r){
                        if(r.code == 0){
                            alert('操作成功', function(){
                                vm.reload();
                            });
                        }else{
                            alert(r.msg);
                        }
                    }
                });
            });
        },
        saveOrUpdate: function () {
            var url = vm.dataTypeConfig.id == null ? "/dataTypeConfig/doAdd.htm" : "/dataTypeConfig/doModify.htm";
            $.ajax({
                type: "POST",
                url: baseURL + url,
                contentType: "application/json",
                data: JSON.stringify(vm.dataTypeConfig),
                success: function(r){
                    if(r.code === 0){
                        alert('操作成功', function(){
                            vm.reload();
                        });
                    }else{
                        alert(r.msg);
                    }
                }
            });
        },
        getDataTypeConfig: function(id){
            $.get(baseURL + "/dataTypeConfig/toModify.htm?id="+id, function(r){
                vm.dataTypeConfig = r.dataTypeConfig;
            });
        },
        reload: function () {
            vm.showList = true;
            var page = $("#jqGrid").jqGrid('getGridParam','page');
            $("#jqGrid").jqGrid('setGridParam',{
                postData:{'jdbcType': vm.q.jdbcType},
                page:page
            }).trigger("reloadGrid");
        }
    }
});