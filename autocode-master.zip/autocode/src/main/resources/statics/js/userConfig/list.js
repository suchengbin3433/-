$(function () {
    $("#jqGrid").jqGrid({
        url: baseURL + '/userConfig/listData.htm',
        datatype: "json",
        colModel: [			
			{ label: '用户ID', name: 'id', index: "id", width: 45, key: true },
			{ label: '用户名', name: 'userName',sortable: false, width: 75 },
            { label: '昵称', name: 'nikeName', sortable: false, width: 75 },
			{ label: '用户类型', name: 'userType',sortable: false, width: 60, formatter: function(value, options, row){
				return value == 1 ? 
					'<span class="label label-danger">管理员</span>' : 
					'<span class="label label-success">普通用户</span>';
			}},
			{ label: '登录次数', name: 'loginTimes', sortable: false, width: 75 },
			{ label: '最后登录时间', name: 'lastLoginTime', sortable: false, width: 75,formatter: function(value, options, row){
				if(value){
					return DateUtil.dateToStr("yyyy/MM/dd HH:mm", new Date(value));
				}
				return "";
			}},
			
			{ label: '最后登录IP', name: 'lastLoginIp', sortable: false, width: 75 }
        ],
		viewrecords: true,
        height: 385,
        rowNum: 10,
		rowList : [10,30,50],
        rownumbers: true, 
        rownumWidth: 25, 
        autowidth:true,
        multiselect: true,
        pager: "#jqGridPager",
        jsonReader : {
            root: "page.list",
            page: "page.currPage",
            total: "page.totalPage",
            records: "page.totalCount"
        },
        prmNames : {
            page:"page", 
            rows:"limit", 
            order: "order"
        },
        gridComplete:function(){
        	//隐藏grid底部滚动条
        	$("#jqGrid").closest(".ui-jqgrid-bdiv").css({ "overflow-x" : "hidden" }); 
        }
    });
});

var vm = new Vue({
    el:'#autocodeapp',
    data:{
        q:{
            userName: null
        },
        showList: true,
        title:null,
        roleList:{},
        user:{
            status:1,
            deptId:null,
            deptName:null,
            roleIdList:[]
        }
    },
    methods: {
        query: function () {
            vm.reload();
        },
        add: function(){
            vm.showList = false;
            vm.title = "新增";
            vm.roleList = {};
            vm.user = {"userType":0};
        },
        update: function () {
            var userId = getSelectedRow();
            if(userId == null){
                return ;
            }

            vm.showList = false;
            vm.title = "修改";

            vm.getUser(userId);
        },
        del: function () {
            var userIds = getSelectedRows();
            if(userIds == null){
                return ;
            }

            confirm('确定要删除选中的记录？', function(){
                $.ajax({
                    type: "POST",
                    url: baseURL + "/userConfig/delete.htm",
                    contentType: "application/json",
                    data: JSON.stringify(userIds),
                    success: function(r){
                        if(r.code == 0){
                            alert('操作成功', function(){
                                vm.reload();
                            });
                        }else{
                            alert(r.msg);
                        }
                    }
                });
            });
        },
        saveOrUpdate: function () {
            var url = vm.user.userId == null ? "/userConfig/doAdd.htm" : "/userConfig/doModify.htm";
            $.ajax({
                type: "POST",
                url: baseURL + url,
                contentType: "application/json",
                data: JSON.stringify(vm.user),
                success: function(r){
                    if(r.code === 0){
                        alert('操作成功', function(){
                            vm.reload();
                        });
                    }else{
                        alert(r.msg);
                    }
                }
            });
        },
        getUser: function(userId){
            $.get(baseURL + "/userConfig/toModify.htm?id="+userId, function(r){
                vm.user = r.user;
                vm.user.password = "";
            });
        },
        reload: function () {
            vm.showList = true;
            var page = $("#jqGrid").jqGrid('getGridParam','page');
            $("#jqGrid").jqGrid('setGridParam',{
                postData:{'userName': vm.q.userName},
                page:page
            }).trigger("reloadGrid");
        }
    }
});