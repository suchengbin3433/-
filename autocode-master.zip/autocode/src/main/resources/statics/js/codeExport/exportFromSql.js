$(function() {
	$("#jqGrid").jqGrid({
		url : baseURL + '/export/analysisTableFromSql.htm',
		datatype : "json",
		colModel : [ {
			label : '表名',
			name : 'tableName',
			sortable : false,
			width : 45,
			key : true
		}, {
			label : '注释',
			name : 'comments',
			sortable : false,
			width : 55
		} ],
		viewrecords : true,
		height : 385,
		rownumbers : true,
		rownumWidth : 25,
		autowidth : true,
		multiselect : true,
		gridComplete : function() {
			// 隐藏grid底部滚动条
			$("#jqGrid").closest(".ui-jqgrid-bdiv").css({
				"overflow-x" : "hidden"
			});
		}
	});
});

var vm = new Vue({
	el : '#autocodeapp',
	data : {
		q : {
			sqlContent : ""
		},
		showList : true,
		title : null,
		exportInfo : {
			templateId: $("#templateConfig").children("option:first").val(),
			dbUrl : "",
			dbUsername : "",
			pakeage : ""
		}
	},
	methods : {
		viewCode : function() {
			var tableNames = vm.setExportParam();
            if(tableNames == null){
           	 return;
            }
            
            $.ajax({
                type: "POST",
                url: baseURL + "/export/viewExport.htm",
                data: {
                	sqlContent : vm.q.sqlContent,
                	javaPakeage : vm.exportInfo.pakeage,
                	templateId : vm.exportInfo.templateId,
                	tableNames : tableNames
                },
                success: function(r){
                    if(r.code === 0){
                    	window.location.href = baseURL + "/fileView.htm?filePath=" + r.filePath;
                    }else{
                        alert(r.msg);
                    }
                }
            });
		},
		exportCode : function() {	// 导出代码
			var tableNames = vm.setExportParam();
            if(tableNames == null){
           	 return;
            }
            
            $("#tableNames").val(tableNames);
            	
            $("#exportForm").submit();
		},
		setExportParam : function(){
        	var sqlContent = vm.q.sqlContent;
        	if(!sqlContent){
        		alert("请先输入Sql语句");
        		return null;
        	}
        	
        	 var tableNames = getSelectedRows("请至少选择一张表");
             if(tableNames == null){
                 return null;
             }
             
             var javaPakeage = vm.exportInfo.pakeage;
             if(!javaPakeage){
            	 alert("请输入包根路径");
         		returnnull;
             }
             
             var templateId = vm.exportInfo.templateId;
             if(!templateId){
            	 alert("请选择模板");
         		return null;
             }
             
             return tableNames.join(",");
        },
		analysisSql : function() {
			vm.reload();
		},
		reload : function() {

			vm.showList = true;

			$("#jqGrid").jqGrid('setGridParam', {
				postData : {
					'sqlContent' : vm.q.sqlContent
				}
			}).trigger("reloadGrid");

		}
	}
});

/*
 * var DbTableConfig = { id: "jqGrid", table: null, layerIndex: -1 };
 * 
 *//**
	 * 初始化表格的列
	 */
/*
 * DbTableConfig.initColumn = function () { var columns = [ {field:
 * 'selectItem', checkbox: true},
 *  ] return columns; };
 * 
 * 
 * function getTemplateConfigId () { var selected =
 * $('#jqGrid').bootstrapTreeTable('getSelections'); if
 * (selected.length == 0) { alert("请选择一条记录"); return null; } else { return
 * selected[0].id; } }
 * 
 * function getTemplateId () { var selected =
 * $('#jqGrid').bootstrapTreeTable('getSelections'); if
 * (selected.length == 0) { alert("请选择一个模板"); return null; } else {
 * 
 * var id = selected[0].id;
 * 
 * if(isTemplateFile(id)){ alert("请选择一个模板"); return null; } return id; } }
 * 
 * $(function () { var colunms = DbTableConfig.initColumn(); var table = new
 * TreeTable(DbTableConfig.id, baseURL + "/export/queryTableFromDb.htm",
 * colunms); table.setExpandColumn(1); table.setIdField("id");
 * table.setCodeField("id"); table.setParentCodeField("parentId");
 * table.setExpandAll(false); table.init(); DbTableConfig.table = table; });
 */
