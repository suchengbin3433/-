$(function () {
    $("#jqGrid").jqGrid({
        url: baseURL + '/export/queryTableFromDb.htm',
        datatype: "json",
        colModel: [			
        	{ label: '表名', name: 'tableName',sortable: false, width: 45, key: true},
            { label: '注释', name: 'comments',sortable: false, width: 55 }
        ],
		viewrecords: true,
        height: 385,
        rownumbers: true, 
        rownumWidth: 25, 
        autowidth:true,
        multiselect: true,
        gridComplete:function(){
        	//隐藏grid底部滚动条
        	$("#jqGrid").closest(".ui-jqgrid-bdiv").css({ "overflow-x" : "hidden" }); 
        }
    });
});



var vm = new Vue({
    el:'#autocodeapp',
    data:{
        q:{
        	databaseId : ""
        },
        showList: true,
        title:null,
        exportInfo :{
        	templateId: $("#templateConfig").children("option:first").val(),
        	dbUrl : "",
        	dbUsername : "",
        	pakeage : ""
        }
    },
    methods: {
        viewCode: function(){	//预览代码
        	
        	var tableNames = vm.setExportParam();
            if(tableNames == null){
           	 return;
            }
            
            $.ajax({
                type: "POST",
                url: baseURL + "/export/viewExport.htm",
                data: {
                	databaseId : vm.q.databaseId,
                	javaPakeage : vm.exportInfo.pakeage,
                	templateId : vm.exportInfo.templateId,
                	tableNames : tableNames
                },
                success: function(r){
                    if(r.code === 0){
                    	window.location.href = baseURL + "/fileView.htm?filePath=" + r.filePath;
                    }else{
                        alert(r.msg);
                    }
                }
            });
            
        },
        exportCode: function () {	//导出代码
        	
             var tableNames = vm.setExportParam();
             if(tableNames == null){
            	 return;
             }
             
             $("#tableNames").val(tableNames);
             	
             $("#exportForm").submit();
        },
        setExportParam : function(){
        	var databaseId = vm.q.databaseId;
        	if(!databaseId){
        		alert("请先选择数据库");
        		return null;
        	}
        	 var tableNames = getSelectedRows("请至少选择一张表");
             if(tableNames == null){
                 return null;
             }
             
             var javaPakeage = vm.exportInfo.pakeage;
             if(!javaPakeage){
            	 alert("请输入包根路径");
         		returnnull;
             }
             
             var templateId = vm.exportInfo.templateId;
             if(!templateId){
            	 alert("请选择模板");
         		return null;
             }
             
             return tableNames.join(",");
        },
        reload: function () {
        	
        	vm.showList = true;
        	var databaseId = vm.q.databaseId;
        	
        	vm.setDatabaseInfo(databaseId);
        	
            $("#jqGrid").jqGrid('setGridParam',{
                postData:{'databaseId': databaseId}
            }).trigger("reloadGrid");
            
            
        },
        setDatabaseInfo: function (databaseId) {
        	vm.exportInfo.dbUrl = $("#option_" + databaseId).attr("dbUrl");
        	vm.exportInfo.dbUsername = $("#option_" + databaseId).attr("dbUsername");
        	vm.exportInfo.pakeage = $("#option_" + databaseId).attr("pakeage");
        },
        validator: function () {
        	return true;
        }
    }
});
