-- 用户配置表
DROP TABLE IF EXISTS `user_config`;
CREATE TABLE `user_config` (
  `id`	BIGINT NOT NULL AUTO_INCREMENT COMMENT '主键自增长ID',
  `user_type` tinyint(1) DEFAULT 0 COMMENT '用户类型：0-普遍用户，1-管理员',
  `user_name` varchar(16) DEFAULT NULL COMMENT '登录用户名',
  `password` varchar(32) DEFAULT NULL COMMENT '登录密码',
  `nike_name` varchar(16) DEFAULT NULL COMMENT '昵称',
  `login_times` int DEFAULT 0 COMMENT '登录次数',
  `last_login_time` BIGINT DEFAULT NULL COMMENT '最后登录时间',
  `last_login_ip` varchar(16) DEFAULT NULL COMMENT '最后登录IP',
  PRIMARY KEY (`id`),
  UNIQUE INDEX `index_user_name`(`user_name`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户配置表';

-- 数据库和java的类型映射配置
DROP TABLE IF EXISTS `data_type_config`;
CREATE TABLE `data_type_config` (
  `id`	BIGINT NOT NULL AUTO_INCREMENT COMMENT '主键自增长ID',
  `db_type` varchar(8) DEFAULT 'mysql' COMMENT '数据库分类',
  `jdbc_type` varchar(16) DEFAULT NULL COMMENT 'jdbc的类型',
  `java_type` varchar(16) DEFAULT NULL COMMENT 'java的类型',
  `java_package` varchar(32) DEFAULT 0 COMMENT 'java类型的包路径',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='数据库和java的类型映射配置';

-- 数据库配置表
DROP TABLE IF EXISTS `database_config`;
CREATE TABLE `database_config` (
  `id`	BIGINT NOT NULL AUTO_INCREMENT COMMENT '主键自增长ID',
  `db_desc` varchar(32) DEFAULT NULL COMMENT '数据库描述',
  `db_type` varchar(8) DEFAULT 'mysql' COMMENT '数据库分类',
  `dbUrl` varchar(64) DEFAULT NULL COMMENT '数据库链接Url',
  `db_name` varchar(32) DEFAULT NULL COMMENT '数据库名',
  `db_username` varchar(32) DEFAULT NULL COMMENT '数据库用户名',
  `db_password` varchar(32) DEFAULT NULL COMMENT '数据库密码',
  `default_template` BIGINT DEFAULT NULL COMMENT '默认的模板ID',
  `default_pakeage` varchar(128) DEFAULT NULL COMMENT '默认的包路径',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='数据库配置表';

-- 模板配置表
DROP TABLE IF EXISTS `template_config`;
CREATE TABLE `template_config` (
  `id`	BIGINT NOT NULL AUTO_INCREMENT COMMENT '主键自增长ID',
  `template_name` varchar(64) DEFAULT NULL COMMENT '模板的名称',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='模板配置表';

-- 模板配置详情表
DROP TABLE IF EXISTS `template_config_detail`;
CREATE TABLE `template_config_detail` (
  `id`	BIGINT NOT NULL AUTO_INCREMENT COMMENT '主键自增长ID',
  `template_id` BIGINT DEFAULT NULL COMMENT '模板ID',
  `template_file_name` varchar(32) DEFAULT NULL COMMENT '模板文件名称',
  `template_type` varchar(8) DEFAULT NULL COMMENT '模板文件分类：java,html,conf等',
  `template_path` varchar(64) DEFAULT NULL COMMENT '模板路径：com...',
  `template_content` varchar(4000) DEFAULT NULL COMMENT '模板内容',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='模板配置详情表';


INSERT INTO `user_config`(`user_type`, `user_name`, `password`, `nike_name`) VALUES (1, 'admin', '21232f297a57a5a743894a0e4a801fc3', '管理员1');