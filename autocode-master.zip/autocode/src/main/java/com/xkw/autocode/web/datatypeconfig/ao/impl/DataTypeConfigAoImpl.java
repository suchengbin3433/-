package com.xkw.autocode.web.datatypeconfig.ao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageInfo;
import com.xkw.autocode.service.DataTypeConfigService;
import com.xkw.autocode.util.PageVo;
import com.xkw.autocode.vo.DataTypeConfigVo;
import com.xkw.autocode.web.datatypeconfig.ao.DataTypeConfigAo;

/**
 * “数据库和java的类型映射配置” Ao实现类
 * 
 * @author auto
 */
@Service("dataTypeConfigAo")
public class DataTypeConfigAoImpl implements DataTypeConfigAo {

	@Autowired
	private DataTypeConfigService dataTypeConfigService;

	/**
	 * 新增操作
	 */
	@Override
	public Boolean insertDataTypeConfig(DataTypeConfigVo dataTypeConfig) {
		if (dataTypeConfig == null) {
			return false;
		}

		int result = dataTypeConfigService.insert(dataTypeConfig);
		if (result == 1) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * 删除操作
	 */
	@Override
	public Boolean deleteDataTypeConfig(Long id) {
		if (id == null) {
			return false;
		}

		int result = dataTypeConfigService.delete(id);
		if (result == 1) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * 修改操作
	 */
	@Override
	public Boolean updateDataTypeConfig(DataTypeConfigVo dataTypeConfig) {
		if (dataTypeConfig == null || dataTypeConfig.getId() == null) {
			return false;
		}

		int result = dataTypeConfigService.update(dataTypeConfig);
		if (result > 0) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * 根据ID查询
	 */
	@Override
	public DataTypeConfigVo queryById(Long id) {
		if (id == null) {
			return null;
		}

		return dataTypeConfigService.findById(id);
	}

	/**
	 * 列表查询
	 */
	@Override
	public List<DataTypeConfigVo> findList(DataTypeConfigVo dataTypeConfigVo) {
		return dataTypeConfigService.fintList(dataTypeConfigVo);
	}

	/**
	 * 分页查询
	 */
	@Override
	public PageInfo<DataTypeConfigVo> queryByPage(DataTypeConfigVo dataTypeConfigVo, Integer pageNo, Integer pageSize,
			String orderBy) {
		return dataTypeConfigService.findByPage(dataTypeConfigVo, new PageVo(pageNo, pageSize, orderBy));
	}
}
