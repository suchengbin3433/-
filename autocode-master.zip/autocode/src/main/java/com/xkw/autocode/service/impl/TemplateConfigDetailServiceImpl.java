package com.xkw.autocode.service.impl;

import java.util.Collections;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.xkw.autocode.mapper.TemplateConfigDetailMapper;
import com.xkw.autocode.model.TemplateConfigDetail;
import com.xkw.autocode.service.TemplateConfigDetailService;
import com.xkw.autocode.util.ExampleUtils;
import com.xkw.autocode.util.ObjectCopyUtils;
import com.xkw.autocode.util.PageVo;
import com.xkw.autocode.vo.TemplateConfigDetailVo;

import tk.mybatis.mapper.entity.Example;

/**
 * “模板配置详情表” 业务类
 * 
 * @author auto
 */
@Service("templateConfigDetailVoService")
public class TemplateConfigDetailServiceImpl implements TemplateConfigDetailService {

	private static final Logger logger = LoggerFactory.getLogger(TemplateConfigDetailServiceImpl.class);

	@Autowired
	private TemplateConfigDetailMapper templateConfigDetailDao;

	/**
	 * 新增操作
	 */
	@Override
	public int insert(TemplateConfigDetailVo templateConfigDetailVo) {
		if (templateConfigDetailVo == null) {
			return 0;
		}

		TemplateConfigDetail templateConfigDetail = this.getTemplateConfigDetail(templateConfigDetailVo);
		if (templateConfigDetail == null) {
			return 0;
		}

		return this.templateConfigDetailDao.insertSelective(templateConfigDetail);
	}

	/**
	 * 根据ID删除操作
	 */
	@Override
	public int delete(Long id) {
		if (id == null || id <= 0) {
			return 0;
		}
		return this.templateConfigDetailDao.deleteByPrimaryKey(id);
	}

	/**
	 * 根据ID删除操作
	 */
	@Override
	public int deleteByTemplateId(Long templateId) {
		if (templateId == null || templateId <= 0) {
			return 0;
		}
		
		Example example = new Example(TemplateConfigDetail.class);
		example.and().andEqualTo("templateId", templateId);
		
		return this.templateConfigDetailDao.deleteByExample(example);
	}
	
	/**
	 * 根据ID更新操作
	 */
	@Override
	public int update(TemplateConfigDetailVo templateConfigDetailVo) {
		if (templateConfigDetailVo == null || templateConfigDetailVo.getId() == null) {
			return 0;
		}

		TemplateConfigDetail templateConfigDetail = this.getTemplateConfigDetail(templateConfigDetailVo);
		if (templateConfigDetail == null) {
			return 0;
		}

		return this.templateConfigDetailDao.updateByPrimaryKeySelective(templateConfigDetail);
	}

	/**
	 * 根据ID查找操作
	 */
	@Override
	public TemplateConfigDetailVo findById(Long id) {
		if (id == null || id <= 0) {
			return null;
		}
		TemplateConfigDetail templateConfigDetail = this.templateConfigDetailDao.selectByPrimaryKey(id);

		try {
			return (TemplateConfigDetailVo) ObjectCopyUtils.copyProperties(templateConfigDetail,
					TemplateConfigDetailVo.class);
		} catch (ReflectiveOperationException e) {
			logger.error("", e);
			return null;
		}
	}

	/**
	 * 根据ID查找操作
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<TemplateConfigDetailVo> findByTemplateId(Long templateId) {
		if (templateId == null || templateId <= 0) {
			Collections.emptyList();
		}

		Example example = new Example(TemplateConfigDetail.class);
		example.and().andEqualTo("templateId", templateId);

		try {
			List<TemplateConfigDetail> templateConfigDetails = this.templateConfigDetailDao.selectByExample(example);

			return ObjectCopyUtils.copyPropertiesList(templateConfigDetails, TemplateConfigDetailVo.class);
		} catch (ReflectiveOperationException e) {
			logger.error("", e);
			return Collections.emptyList();
		}
	}

	/**
	 * 分页查找接口
	 */
	@Override
	public PageInfo<TemplateConfigDetailVo> findByPage(TemplateConfigDetailVo templateConfigDetailVo, PageVo pageVo) {

		TemplateConfigDetail templateConfigDetail = this.getTemplateConfigDetail(templateConfigDetailVo);
		if (templateConfigDetail == null) {
			return null;
		}

		return this.findByPage(templateConfigDetail, pageVo.getPageNo(), pageVo.getPageSize(), pageVo.getOrderBy());
	}

	/**
	 * 分页查找
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private PageInfo<TemplateConfigDetailVo> findByPage(TemplateConfigDetail templateConfigDetail, int pageNo,
			int pageSize, String orderBy) {
		PageHelper.startPage(pageNo, pageSize);
		if (orderBy != null && orderBy.length() > 0) {
			PageHelper.orderBy(orderBy);
		}

		Example example = ExampleUtils.getExampleFromObject(templateConfigDetail);

		List<TemplateConfigDetail> list = this.templateConfigDetailDao.selectByExample(example);
		try {
			PageInfo pageInfo = new PageInfo<>(list);
			pageInfo.setList(ObjectCopyUtils.copyPropertiesList(list, TemplateConfigDetailVo.class));
			return pageInfo;
		} catch (ReflectiveOperationException e) {
			logger.error("", e);
			return null;
		}

	}

	private TemplateConfigDetail getTemplateConfigDetail(TemplateConfigDetailVo templateConfigDetailVo) {
		try {
			return (TemplateConfigDetail) ObjectCopyUtils.copyProperties(templateConfigDetailVo,
					TemplateConfigDetail.class);
		} catch (ReflectiveOperationException e) {
			logger.error("", e);
			return null;
		}
	}
}
