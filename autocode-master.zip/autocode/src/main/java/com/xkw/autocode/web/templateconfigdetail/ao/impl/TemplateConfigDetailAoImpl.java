package com.xkw.autocode.web.templateconfigdetail.ao.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xkw.autocode.service.TemplateConfigDetailService;
import com.xkw.autocode.vo.TemplateConfigDetailVo;
import com.xkw.autocode.web.templateconfigdetail.ao.TemplateConfigDetailAo;

/**
 * “模板配置详情表”	Ao实现类
 * @author auto
*/
@Service("templateConfigDetailAo")
public class TemplateConfigDetailAoImpl implements TemplateConfigDetailAo {
	
	@Autowired
	private TemplateConfigDetailService templateConfigDetailService;

	/**
	 * 新增操作
	 */
	@Override
	public Boolean insertTemplateConfigDetail(TemplateConfigDetailVo templateConfigDetail){
		if(templateConfigDetail == null){
			return false;
		}
		
		int result = templateConfigDetailService.insert(templateConfigDetail);
		if(result == 1){
			return true;
		}else{
			return false;
		}
	}
	
	/**
	 * 删除操作
	 */
	@Override
	public Boolean deleteTemplateConfigDetail(Long id){
		if(id == null){
			return false;
		}
		
		int result = templateConfigDetailService.delete(id);
		if(result == 1){
			return true;
		}else{
			return false;
		}
	}
	
	/**
	 * 修改操作
	 */
	@Override
	public Boolean updateTemplateConfigDetail(TemplateConfigDetailVo templateConfigDetail){
		if(templateConfigDetail == null || templateConfigDetail.getId() == null){
			return false;
		}
		
		int result = templateConfigDetailService.update(templateConfigDetail);
		if(result > 0){
			return true;
		}else{
			return false;
		}
	}
	
	/**
	 * 根据ID查询
	 */
	@Override
	public TemplateConfigDetailVo queryById(Long id){
		if(id == null){
			return null;
		}
		
		return  templateConfigDetailService.findById(id);
	}
}
