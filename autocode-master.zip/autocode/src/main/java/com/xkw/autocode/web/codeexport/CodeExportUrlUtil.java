package com.xkw.autocode.web.codeexport;

import com.xkw.autocode.base.BaseURL;

/**
 * 数据库配置表 请求地址
 * 
 * @author auto
 */
public class CodeExportUrlUtil extends BaseURL {

	public static final String BASE = "/export/";

	/** 进入通过DB导出 */
	public static final String TO_EXPORT_FROM_DB = BASE + "exportFromDb" + DYNAMIC_WEB_SUFFIX;

	/** 通过DB导出 */
	public static final String DO_EXPORT_FROM_DB = BASE + "doExportFromDb" + DYNAMIC_WEB_SUFFIX;

	/** 进入通过sql导出 */
	public static final String TO_EXPORT_FROM_SQL = BASE + "exportFromSql" + DYNAMIC_WEB_SUFFIX;
	
	/** 通过Sql导出 */
	public static final String DO_EXPORT_FROM_SQL = BASE + "doExportFromSql" + DYNAMIC_WEB_SUFFIX;
	
	/** 通过路径导出 */
	public static final String DO_EXPORT_FROM_PATH = BASE + "doExportFromPath" + DYNAMIC_WEB_SUFFIX;

	/** 查询表 */
	public static final String QUERY_TABLE_FROM_DB = BASE + "queryTableFromDb" + DYNAMIC_WEB_SUFFIX;

	/** 解析表 */
	public static final String ANALYSIS_TABLE_FROM_SQL = BASE + "analysisTableFromSql" + DYNAMIC_WEB_SUFFIX;

	/** 查看模板关键字示例 */
	public static final String TO_KEYWORDS_DEMO = BASE + "keywordsDemo" + DYNAMIC_WEB_SUFFIX;
	
	/** 预览*/
	public static final String VIEW_EXPORT = BASE + "viewExport" + DYNAMIC_WEB_SUFFIX;

}
