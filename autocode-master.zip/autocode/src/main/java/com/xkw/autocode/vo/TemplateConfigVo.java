package com.xkw.autocode.vo;

import com.xkw.autocode.base.BaseVo;

/**
 * 模板配置表
 * 
 * @author auto
 */
public class TemplateConfigVo extends BaseVo {

	private static final long serialVersionUID = 1L;

	/**
	 * 模板的名称
	 */
	private String templateName;

	/**
	 * GET.模板的名称
	 */
	public String getTemplateName() {
		return this.templateName;
	}

	/**
	 * SET.模板的名称
	 */
	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

}
