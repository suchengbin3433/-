package com.xkw.autocode.enums;

public enum AdminTypeEnum {

	ADMIN("管理员", 1),

	NORMAL("普通用户", 0);

	private String desc;

	/** 枚举值 */
	private int value;

	private AdminTypeEnum(String desc, int value) {
		this.desc = desc;
		this.value = value;
	}

	public String getDesc() {
		return desc;
	}

	public int getValue() {
		return value;
	}

}
