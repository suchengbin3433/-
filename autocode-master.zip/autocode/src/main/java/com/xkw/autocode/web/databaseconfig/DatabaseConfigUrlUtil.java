package com.xkw.autocode.web.databaseconfig;

import com.xkw.autocode.base.BaseURL;

/**
 * 数据库配置表 请求地址
 * @author auto
 */
public class DatabaseConfigUrlUtil  extends BaseURL{
	
	/** 列表 */
	public static final String LIST = "/databaseConfig/list"+ DYNAMIC_WEB_SUFFIX ;
	public static final String LIST_DATA = "/databaseConfig/listData"+ DYNAMIC_WEB_SUFFIX ;
	
	/** 新增 */
	public static final String DO_ADD = "/databaseConfig/doAdd"+ DYNAMIC_WEB_SUFFIX ;
	
	/** 修改 */
	public static final String TO_MODIFY = "/databaseConfig/toModify"+ DYNAMIC_WEB_SUFFIX ;
	public static final String DO_MODIFY = "/databaseConfig/doModify"+ DYNAMIC_WEB_SUFFIX ;
	
	/** 删除 */
	public static final String DO_DELETE = "/databaseConfig/delete"+ DYNAMIC_WEB_SUFFIX ;
}
