package com.xkw.autocode.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

public class FileUtils {

	private FileUtils() {
	}

	public static void deleteFile(String path) {
		deleteFile(new File(path));
	}

	public static void deleteFile(File file) {
		if (!file.exists()) {
			return;
		}
		if (file.isFile()) {
			file.delete();
		} else {
			File[] files = file.listFiles();
			if (files.length > 0) {
				for (File f : files) {
					deleteFile(f);
				}
			}
			file.delete();
		}
	}

	public static void copyFile(File source, File dest) {
		if (!source.exists() || source.isDirectory()) {
			return;
		}
		InputStream input = null;
		OutputStream output = null;
		try {
			if (!dest.getParentFile().exists()) {
				dest.getParentFile().mkdirs();
			}
			input = new FileInputStream(source);
			output = new FileOutputStream(dest);
			byte[] buf = new byte[1024];
			int bytesRead;
			while ((bytesRead = input.read(buf)) > 0) {
				output.write(buf, 0, bytesRead);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (input != null) {
					input.close();
				}

				if (output != null) {
					output.close();
				}

			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public static List<String> readFile(File file) throws Exception {
		List<String> lines = new ArrayList<String>();
		if (!file.exists()) {
			return lines;
		}

		InputStreamReader read = null;
		BufferedReader reader = null;
		try {
			read = new InputStreamReader(new FileInputStream(file));
			reader = new BufferedReader(read, 2 * 1048576);

			String line = "";

			while ((line = reader.readLine()) != null) {

				/********* start 解析一行数据 ************/
				try {
					lines.add(line);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			reader.close();
			read.close();
		}
		return lines;
	}

	public static String readFileString(File file) throws Exception {
		List<String> lines = FileUtils.readFile(file);
		StringBuilder sbl = new StringBuilder();
		for (String line : lines) {
			sbl.append(line).append("\n");
		}
		return sbl.toString();
	}

	public static void writeToFile(String filePath, String str) throws Exception {
		writeToFile(filePath, str, false);
	}

	public static void writeToFile(String filePath, String str, boolean bak) throws Exception {
		File file = new File(filePath);
		if (file.exists()) {
			file.delete();
		} else {
			if (!file.getParentFile().exists()) {
				file.getParentFile().mkdirs();
			}
		}
		try {
			// 打开一个写文件器，构造函数中的第二个参数true表示以追加形式写文件
			FileWriter writer = new FileWriter(filePath);
			writer.write(str);
			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

		// 生成备份文件
		if (bak && filePath.indexOf("template") != -1) {
			String bakPath = filePath.replace("template", "template-bak") + "."
					+ MyDateUtils.formatDateTime("yyyy-MM-dd-HH-mm-ss", System.currentTimeMillis());
			FileUtils.writeToFile(bakPath, str, false);
		}
	}

	/**
	 * 获取所有的文件
	 * 
	 * @param path
	 * @return
	 */
	public static void getFiles(List<File> files, File file) {
		if (file.isFile()) {
			files.add(file);
		} else {
			File[] fileArray = file.listFiles();

			for (File f : fileArray) {
				getFiles(files, f);
			}
		}
	}
}
