package com.xkw.autocode.web.datatypeconfig.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.github.pagehelper.PageInfo;
import com.xkw.autocode.base.BaseController;
import com.xkw.autocode.util.PageUtils;
import com.xkw.autocode.util.QueryUtils;
import com.xkw.autocode.vo.DataTypeConfigVo;
import com.xkw.autocode.web.common.Result;
import com.xkw.autocode.web.datatypeconfig.DataTypeConfigUrlUtil;
import com.xkw.autocode.web.datatypeconfig.ao.DataTypeConfigAo;

/**
 * “数据库和java的类型映射配置” Controller类
 * 
 * @author auto
 */
@Controller
public class DataTypeConfigController extends BaseController {

	@Autowired
	private DataTypeConfigAo dataTypeConfigAo;

	/**
	 * 跳转到列表页面
	 */
	@RequestMapping(value = DataTypeConfigUrlUtil.LIST)
	public ModelAndView list() {
		ModelAndView modelAndView = new ModelAndView();

		modelAndView.setViewName("dataTypeConfig/list");
		return modelAndView;
	}

	/**
	 * 获取列表页面的数据
	 */
	@RequestMapping(value = DataTypeConfigUrlUtil.LIST_DATA)
	@ResponseBody
	public Object listData(HttpServletRequest request, DataTypeConfigVo dataTypeConfigVo) {

		QueryUtils query = QueryUtils.newInstance(request);
		
		PageInfo<DataTypeConfigVo> pageInfo = dataTypeConfigAo.queryByPage(dataTypeConfigVo,query.getPageNo(), query.getPageSize(),
				query.getOrderBy());

		return Result.ok().put("page", new PageUtils(pageInfo));
	}

	/**
	 * 删除操作
	 */
	@RequestMapping(value = DataTypeConfigUrlUtil.DO_DELETE)
	@ResponseBody
	public Result doDelete(@RequestBody Long[] ids) {

		if (ids != null && ids.length > 0) {

			for (Long id : ids) {
				dataTypeConfigAo.deleteDataTypeConfig(id);
			}
		}
		return Result.ok();
	}

	/**
	 * 跳转到修改页面
	 */
	@RequestMapping(value = DataTypeConfigUrlUtil.TO_MODIFY)
	@ResponseBody
	public Result toModify(Long id) {
		return Result.ok().put("dataTypeConfig", dataTypeConfigAo.queryById(id));
	}

	/**
	 * 新增操作
	 */
	@RequestMapping(value = DataTypeConfigUrlUtil.DO_ADD)
	@ResponseBody
	public Object doAdd(HttpServletRequest request, @RequestBody DataTypeConfigVo dataTypeConfig) {
		return doAddOrModify(dataTypeConfig);
	}

	/**
	 * 编辑操作
	 */
	@RequestMapping(value = DataTypeConfigUrlUtil.DO_MODIFY)
	@ResponseBody
	public Object doModify(HttpServletRequest request, @RequestBody DataTypeConfigVo dataTypeConfig) {
		return doAddOrModify(dataTypeConfig);
	}

	/**
	 * 新增或者编辑操作
	 */
	private Object doAddOrModify(DataTypeConfigVo dataTypeConfig) {
		boolean result = false;
		if (dataTypeConfig != null) {
			if (dataTypeConfig.getId() != null) {
				result = dataTypeConfigAo.updateDataTypeConfig(dataTypeConfig);
			} else {
				result = dataTypeConfigAo.insertDataTypeConfig(dataTypeConfig);
			}
		}
		if (result) {
			return Result.ok();
		} else {
			return Result.ok("操作失败");
		}
	}
}
