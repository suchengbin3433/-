package com.xkw.autocode.code;

import java.util.List;
import java.util.Map;

import com.xkw.autocode.jdbc.entity.ColumnEntity;

/**
 * 生成 mybatis xml的方法
 * 
 * @author xiangkaiwei
 *
 */
public class MybatisTemplateUtils {

	private MybatisTemplateUtils() {
	}

	/**
	 * 
	 * @param columns
	 * @return
	 */
	public static void setMybatisXmlProperty(List<ColumnEntity> columns, Map<String, String> map) {

		StringBuilder resultMap = new StringBuilder();
		StringBuilder columnList = new StringBuilder();

		StringBuilder insertColumns = new StringBuilder();
		StringBuilder insertValues = new StringBuilder();

		StringBuilder updateColumns = new StringBuilder();

		StringBuilder whereColumns = new StringBuilder();

		int n = 0;
		for (ColumnEntity column : columns) {

			String columnName = column.getColumnName();
			String attrName = CodeUtils.getAttrName(columnName);

			String jdbcType = column.getJdbcType();

			if (jdbcType.equalsIgnoreCase("int")) {
				jdbcType = "INTEGER";
			}
			if (resultMap.length() > 0) {
				resultMap.append("\n");
			}

			resultMap.append("\t<result column=\"" + columnName + "\" property=\"" + attrName + "\"");

			if (jdbcType != null && !"".equals(jdbcType)) {
				resultMap.append(" jdbcType=\"" + jdbcType + "\"");
			}
			resultMap.append("/>");

			if (columnList.length() > 0) {
				columnList.append(", ");
			}
			if (n > 0 && n % 5 == 0) {
				columnList.append("\n\t");
			}
			columnList.append(columnName);

			if (columnName.equals("id")) {
				continue;
			}
			// insert
			insertColumns.append(CodeUtils.getSqlInsertColumn(attrName, columnName));
			insertValues.append(CodeUtils.getSqlInsertValue(attrName, columnName, jdbcType));

			// update
			updateColumns.append(CodeUtils.getSqlUpdateColumn(attrName, columnName, jdbcType));

			// where
			whereColumns.append(CodeUtils.getSqlWhere(attrName, columnName, jdbcType));

			n++;
		}

		map.put("Mybatis_Result_Map", resultMap.toString());
		map.put("Mybatis_Column_List", columnList.toString());

		map.put("Mybatis_Insert_Columns", insertColumns.toString());
		map.put("Mybatis_Insert_Values", insertValues.toString());

		map.put("Mybatis_Update_Columns", updateColumns.toString());
		map.put("Mybatis_Where_Columns", whereColumns.toString());

	}

}
