package com.xkw.autocode.code;

import java.util.List;

import com.xkw.autocode.jdbc.entity.ColumnEntity;

/**
 * html 模板生成
 * 
 * @author xiangkaiwei
 *
 */
public class HtmlTemplateUtils {

	private HtmlTemplateUtils() {

	}

	// 获取列表表头的html
	public static String getThHtml(List<ColumnEntity> columns) {
		StringBuilder thSbl = new StringBuilder();

		int w = 100 / columns.size();

		for (ColumnEntity column : columns) {
			if (column.getColumnName().equalsIgnoreCase("id")) {
				continue;
			}

			String desc = column.getComments(); // 注释

			if (thSbl.length() > 0) {
				thSbl.append("\t\t\t\t\t\t\t\t\t");
			}

			// 列表表头
			thSbl.append("<th width=\"" + w + "%\">" + desc + "</th>").append("\n");
		}
		thSbl.append("\t\t\t\t\t\t\t\t\t").append("<th width=\"" + w + "%\">操作</th>").append("\n");

		return thSbl.toString();
	}

	// 获取表格加载的datatable的脚本
	public static String getDatatableScript(List<ColumnEntity> columns) {

		StringBuilder thSbl = new StringBuilder();

		for (ColumnEntity column : columns) {
			if (column.getColumnName().equalsIgnoreCase("id")) {
				continue;
			}

			// 属性名
			String attrName = CodeUtils.getAttrName(column.getColumnName());

			// 列表内容
			if (thSbl.length() > 0) {
				thSbl.append("\t\t,").append("\n");
			}
			thSbl.append("\t\t{").append("\n");
			thSbl.append("\t\t\tdata:'" + attrName + "',").append("\n");
			thSbl.append("\t\t\trender:function (data, type, full, meta) {").append("\n");
			thSbl.append("\t\t\t\treturn data;").append("\n");
			thSbl.append("\t\t\t}").append("\n");
			thSbl.append("\t\t}").append("\n");
		}

		thSbl.append("\t\t,").append("\n");
		thSbl.append("\t\t{").append("\n");
		thSbl.append("\t\t\tdata:'id',").append("\n");
		thSbl.append("\t\t\trender:function (data, type, full, meta) {").append("\n");

		thSbl.append("\t\t\t\tvar id = data;").append("\n");
		thSbl.append(
				"\t\t\t\tvar returnHtml = \"<a href=\\\"${ctx}/{model_name_attr}/toModify.htm?id=\"+id+\"\\\">编辑</a>\";")
				.append("\n");
		thSbl.append(
				"\t\t\t\treturnHtml += \"<a class=\\\"margin-left-10\\\" href=\\\"javascript:void(0);\\\" onclick=\\\"doDelete(\"+id+\")\\\">删除</a>\";")
				.append("\n");
		thSbl.append("\t\t\t\treturn returnHtml;").append("\n");
		thSbl.append("\t\t\t}").append("\n");
		thSbl.append("\t\t}").append("\n");

		return thSbl.toString();
	}
}
