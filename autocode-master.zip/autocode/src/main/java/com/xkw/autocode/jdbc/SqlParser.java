package com.xkw.autocode.jdbc;

import java.util.List;

import com.xkw.autocode.jdbc.entity.TableEntity;

/**
 * sql解析器
 * 
 * @author xiangkaiwei
 *
 */
public interface SqlParser {

	public List<TableEntity> getTableFromSql(String sql);

	public List<TableEntity> getTableFromSql(String sql, String tableNames);

}
