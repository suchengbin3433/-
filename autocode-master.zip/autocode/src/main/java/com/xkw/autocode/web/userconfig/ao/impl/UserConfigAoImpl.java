package com.xkw.autocode.web.userconfig.ao.impl;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageInfo;
import com.xkw.autocode.service.UserConfigService;
import com.xkw.autocode.util.PageVo;
import com.xkw.autocode.vo.UserConfigVo;
import com.xkw.autocode.web.userconfig.ao.UserConfigAo;

/**
 * “用户配置表”	Ao实现类
 * @author auto
*/
@Service("userConfigAo")
public class UserConfigAoImpl implements UserConfigAo {
	
	@Autowired
	private UserConfigService userConfigService;

	/**
	 * 新增操作
	 */
	@Override
	public Boolean insertUserConfig(UserConfigVo userConfig){
		if(userConfig == null){
			return false;
		}
		
		int result = userConfigService.insert(userConfig);
		if(result == 1){
			return true;
		}else{
			return false;
		}
	}
	
	/**
	 * 删除操作
	 */
	@Override
	public Boolean deleteUserConfig(Long id){
		if(id == null){
			return false;
		}
		
		int result = userConfigService.delete(id);
		if(result == 1){
			return true;
		}else{
			return false;
		}
	}
	
	/**
	 * 修改操作
	 */
	@Override
	public Boolean updateUserConfig(UserConfigVo userConfig){
		if(userConfig == null || userConfig.getId() == null){
			return false;
		}
		
		int result = userConfigService.update(userConfig);
		if(result > 0){
			return true;
		}else{
			return false;
		}
	}
	
	/**
	 * 根据ID查询
	 */
	@Override
	public UserConfigVo queryById(Long id){
		if(id == null){
			return null;
		}
		
		return  userConfigService.findById(id);
	}
	
	/**
	 * 根据用户名查询
	 */
	@Override
	public UserConfigVo queryByUserName(String userName) {
		if(StringUtils.isEmpty(userName)){
			return null;
		}
		
		return  userConfigService.queryByUserName(userName);
	}
	
	/**
	 * 列表查询
	 */
	@Override
	public PageInfo<UserConfigVo> queryByPage(UserConfigVo userConfig,Integer pageNo,Integer pageSize,String orderBy){
		return userConfigService.findByPage(userConfig,new PageVo(pageNo, pageSize, orderBy));
	}
}
