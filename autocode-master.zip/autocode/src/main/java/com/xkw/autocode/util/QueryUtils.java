
package com.xkw.autocode.util;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;

/**
 * 查询参数
 */
public class QueryUtils {

	/**
	 * 当前页码
	 */
	private static final String PAGE = "page";
	/**
	 * 每页显示记录数
	 */
	private static final String LIMIT = "limit";
	/**
	 * 排序字段
	 */
	private static final String ORDER_FIELD = "sidx";
	/**
	 * 排序方式
	 */
	private static final String ORDER = "order";
	/**
	 * 升序
	 */
	private static final String ASC = "asc";

	private static final String DESC = "desc";

	private Integer pageNo;
	private Integer pageSize;
	private String orderBy;

	public static QueryUtils newInstance(HttpServletRequest request) {
		QueryUtils query = new QueryUtils();

		// 分页参数
		int curPage = 1;
		int limit = 10;

		if (request.getParameter(PAGE) != null) {
			curPage = Integer.parseInt((String) request.getParameter(PAGE));
		}
		if (request.getParameter(LIMIT) != null) {
			limit = Integer.parseInt((String) request.getParameter(LIMIT));
		}

		// 排序字段
		String orderField = request.getParameter(ORDER_FIELD);
		String order = request.getParameter(ORDER);

		// 前端字段排序
		if (StringUtils.isNotEmpty(orderField)) {
			if (!ASC.equalsIgnoreCase(order)) {
				order = DESC;
			}
			query.orderBy = orderField + " " + order;
		}

		query.pageNo = curPage;
		query.pageSize = limit;

		return query;
	}

	public Integer getPageNo() {
		return pageNo;
	}

	public Integer getPageSize() {
		return pageSize;
	}

	public String getOrderBy() {
		return orderBy;
	}

}
