package com.xkw.autocode.service;

import java.util.List;

import com.github.pagehelper.PageInfo;
import com.xkw.autocode.util.PageVo;
import com.xkw.autocode.vo.DataTypeConfigVo;

/**
 * “数据库和java的类型映射配置”	业务对内接口类
 * @author auto
*/
public interface DataTypeConfigService{

	/**
	 * 新增接口
	 * @param dataTypeConfig
	 * @return
	*/
	public int insert(DataTypeConfigVo dataTypeConfig);

	/**
	 * 根据ID删除接口
	 * @param id
	 * @return
	*/
	public int delete(Long id);

	/**
	 * 根据ID更新接口
	 * @param dataTypeConfig
	 * @return
	*/
	public int update(DataTypeConfigVo dataTypeConfig);

	/**
	 * 根据ID查找接口
	 * @param id
	 * @return
	*/
	public DataTypeConfigVo findById(Long id);
	
	/**
	 * 分页查找接口（可带分页条件）
	 * @param dataTypeConfig
	 * @param page
	 * @return
	*/
	public List<DataTypeConfigVo> fintList(DataTypeConfigVo dataTypeConfig);

	/**
	 * 分页查找接口（可带分页条件）
	 * @param dataTypeConfig
	 * @param page
	 * @return
	 */
	public PageInfo<DataTypeConfigVo> findByPage(DataTypeConfigVo dataTypeConfig,PageVo page);

}

