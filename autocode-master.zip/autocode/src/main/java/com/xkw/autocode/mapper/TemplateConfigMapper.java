package com.xkw.autocode.mapper;

import com.xkw.autocode.base.BaseMapper;
import com.xkw.autocode.model.TemplateConfig;

/**
 * “模板配置表” Mapper 类
 * @author auto
*/
public interface TemplateConfigMapper extends BaseMapper<TemplateConfig>{
	
}
