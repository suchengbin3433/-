package com.xkw.autocode.web.userconfig;

import com.xkw.autocode.base.BaseURL;

/**
 * 用户配置表 请求地址
 * @author auto
 */
public class UserConfigUrlUtil  extends BaseURL{
	
	/** 列表 */
	public static final String LIST = "/userConfig/list"+ DYNAMIC_WEB_SUFFIX ;
	public static final String LIST_DATA = "/userConfig/listData"+ DYNAMIC_WEB_SUFFIX ;
	
	/** 新增 */
	public static final String DO_ADD = "/userConfig/doAdd"+ DYNAMIC_WEB_SUFFIX ;
	
	/** 修改 */
	public static final String TO_MODIFY = "/userConfig/toModify"+ DYNAMIC_WEB_SUFFIX ;
	public static final String DO_MODIFY = "/userConfig/doModify"+ DYNAMIC_WEB_SUFFIX ;
	
	/** 删除 */
	public static final String DO_DELETE = "/userConfig/delete"+ DYNAMIC_WEB_SUFFIX ;
}
