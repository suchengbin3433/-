package com.xkw.autocode.vo;

import com.xkw.autocode.base.BaseVo;

/**
 * 模板配置详情表
 * 
 * @author auto
 */
public class TemplateConfigDetailVo extends BaseVo {

	private static final long serialVersionUID = 1L;

	/**
	 * 模板ID
	 */
	private Long templateId;

	/**
	 * 模板文件名称
	 */
	private String templateFileName;

	/**
	 * 模板文件分类：JAVAHTMLCONF等
	 */
	private String templateType;

	/**
	 * 模板路径：COM...
	 */
	private String templatePath;

	/**
	 * 模板内容
	 */
	private String templateContent;

	/**
	 * GET.模板ID
	 */
	public Long getTemplateId() {
		return this.templateId;
	}

	/**
	 * SET.模板ID
	 */
	public void setTemplateId(Long templateId) {
		this.templateId = templateId;
	}

	/**
	 * GET.模板文件名称
	 */
	public String getTemplateFileName() {
		return this.templateFileName;
	}

	/**
	 * SET.模板文件名称
	 */
	public void setTemplateFileName(String templateFileName) {
		this.templateFileName = templateFileName;
	}

	/**
	 * GET.模板文件分类：JAVAHTMLCONF等
	 */
	public String getTemplateType() {
		return this.templateType;
	}

	/**
	 * SET.模板文件分类：JAVAHTMLCONF等
	 */
	public void setTemplateType(String templateType) {
		this.templateType = templateType;
	}

	/**
	 * GET.模板路径：COM...
	 */
	public String getTemplatePath() {
		return this.templatePath;
	}

	/**
	 * SET.模板路径：COM...
	 */
	public void setTemplatePath(String templatePath) {
		this.templatePath = templatePath;
	}

	/**
	 * GET.模板内容
	 */
	public String getTemplateContent() {
		return this.templateContent;
	}

	/**
	 * SET.模板内容
	 */
	public void setTemplateContent(String templateContent) {
		this.templateContent = templateContent;
	}

}
