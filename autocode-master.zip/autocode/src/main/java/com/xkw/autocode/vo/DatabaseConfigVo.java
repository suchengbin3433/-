package com.xkw.autocode.vo;

import com.xkw.autocode.base.BaseVo;

/**
 * 数据库配置表
 * @author auto
*/
public class DatabaseConfigVo extends BaseVo  {

	private static final long serialVersionUID = 1L;

	/**
	 * 数据库描述
	 */
	private String dbDesc;

	/**
	 * 数据库分类
	 */
	private String dbType;

	/**
	 * 数据库链接URL
	 */
	private String dbUrl;

	/**
	 * 数据库名
	 */
	private String dbName;

	/**
	 * 数据库用户名
	 */
	private String dbUsername;

	/**
	 * 数据库密码
	 */
	private String dbPassword;

	/**
	 * 默认的模板ID
	 */
	private Long defaultTemplate;

	/**
	 * 默认的包路径
	 */
	private String defaultPakeage;

	/**
	 * GET.数据库描述
	 */
	public String getDbDesc() {
		return this.dbDesc;
	}

	/**
	 * SET.数据库描述
	 */
	public void setDbDesc(String dbDesc) {
		this.dbDesc = dbDesc;
	}

	/**
	 * GET.数据库分类
	 */
	public String getDbType() {
		return this.dbType;
	}

	/**
	 * SET.数据库分类
	 */
	public void setDbType(String dbType) {
		this.dbType = dbType;
	}

	/**
	 * GET.数据库链接Url
	 */
	public String getDbUrl() {
		return dbUrl;
	}

	/**
	 * SET.数据库链接Url
	 */
	public void setDbUrl(String dbUrl) {
		this.dbUrl = dbUrl;
	}

	/**
	 * GET.数据库名
	 */
	public String getDbName() {
		return this.dbName;
	}

	/**
	 * SET.数据库名
	 */
	public void setDbName(String dbName) {
		this.dbName = dbName;
	}

	/**
	 * GET.数据库用户名
	 */
	public String getDbUsername() {
		return this.dbUsername;
	}

	/**
	 * SET.数据库用户名
	 */
	public void setDbUsername(String dbUsername) {
		this.dbUsername = dbUsername;
	}

	/**
	 * GET.数据库密码
	 */
	public String getDbPassword() {
		return this.dbPassword;
	}

	/**
	 * SET.数据库密码
	 */
	public void setDbPassword(String dbPassword) {
		this.dbPassword = dbPassword;
	}

	/**
	 * GET.默认的模板ID
	 */
	public Long getDefaultTemplate() {
		return this.defaultTemplate;
	}

	/**
	 * SET.默认的模板ID
	 */
	public void setDefaultTemplate(Long defaultTemplate) {
		this.defaultTemplate = defaultTemplate;
	}

	/**
	 * GET.默认的包路径
	 */
	public String getDefaultPakeage() {
		return this.defaultPakeage;
	}

	/**
	 * SET.默认的包路径
	 */
	public void setDefaultPakeage(String defaultPakeage) {
		this.defaultPakeage = defaultPakeage;
	}


}


