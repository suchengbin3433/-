package com.xkw.autocode.web.templateconfigdetail.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.xkw.autocode.base.BaseController;
import com.xkw.autocode.vo.TemplateConfigDetailVo;
import com.xkw.autocode.web.common.Result;
import com.xkw.autocode.web.templateconfigdetail.TemplateConfigDetailUrlUtil;
import com.xkw.autocode.web.templateconfigdetail.ao.TemplateConfigDetailAo;

/**
 * “模板配置详情表”	 Controller类
 * @author auto
*/
@Controller
public class TemplateConfigDetailController extends BaseController{
	
	@Autowired
	private TemplateConfigDetailAo templateConfigDetailAo;		
	
	/**
	 * 跳转到模板内容预览页面
	 */
	@RequestMapping(value = TemplateConfigDetailUrlUtil.VIEW_CONTENT)
	public ModelAndView viewContent(Long id) {
		ModelAndView modelAndView = new ModelAndView();

		modelAndView.addObject("templateConfigDetail", templateConfigDetailAo.queryById(id));
		
		modelAndView.setViewName("templateConfig/viewContent");
		return modelAndView;
	}
	
	/**
	 * 删除操作
	 */
	@RequestMapping(value = TemplateConfigDetailUrlUtil.DO_DELETE)
	@ResponseBody
	public Object doDelete(Long id) {
		
		templateConfigDetailAo.deleteTemplateConfigDetail(id);
		return Result.ok();
	}
	
	/**
	 * 跳转到修改页面
	 */
	@RequestMapping(value = TemplateConfigDetailUrlUtil.TO_MODIFY)
	@ResponseBody
	public Result toModify(Long id) {
		
		return Result.ok().put("templateConfig", templateConfigDetailAo.queryById(id));
	}
	
	/**
	 * 新增操作
	 */
	@RequestMapping(value = TemplateConfigDetailUrlUtil.DO_ADD)
	@ResponseBody
	public Object doAdd(HttpServletRequest request,@RequestBody TemplateConfigDetailVo templateConfigDetail) {
		return doAddOrModify(templateConfigDetail);
	}
	
	/**
	 * 编辑操作
	 */
	@RequestMapping(value = TemplateConfigDetailUrlUtil.DO_MODIFY)
	@ResponseBody
	public Object doModify(HttpServletRequest request,@RequestBody TemplateConfigDetailVo templateConfigDetail) {
		return doAddOrModify(templateConfigDetail);
	}
	
	/**
	 * 新增或者编辑操作
	 */
	private Object doAddOrModify(TemplateConfigDetailVo templateConfigDetail){
		boolean result = false;
		if(templateConfigDetail != null){
			if(templateConfigDetail.getId() != null){
				result = templateConfigDetailAo.updateTemplateConfigDetail(templateConfigDetail);
			}else{
				result = templateConfigDetailAo.insertTemplateConfigDetail(templateConfigDetail);
			}
		}
		if (result) {
			return Result.ok();
		} else {
			return Result.ok("操作失败");
		}
	}
}
