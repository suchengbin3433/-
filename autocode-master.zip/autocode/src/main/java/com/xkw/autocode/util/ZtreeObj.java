package com.xkw.autocode.util;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 封装Ztree的相关属性	 
 */
public class ZtreeObj {

	private Object id; //id
	
	private Object pId;	//pid
	
	private String name; //树节点显示的名称
	
	private Boolean open;	//树节点是否打开（true：打开状态）
	
	private Boolean nocheck; //树节点是否带复选框（false：带复选框）

	private Boolean checked;
	
	private String desc;
	
	private Boolean disable;
	
	private List<ZtreeObj> subNode;
	
	public ZtreeObj() {
		super();
	}

	public ZtreeObj(Object id, Object pId, String name, Boolean open, Boolean nocheck, boolean checked) {
		super();
		this.id = id;
		this.pId = pId;
		this.name = name;
		this.open = open;
		this.nocheck = nocheck;
		this.checked = checked;
	}

	public Object getId() {
		return id;
	}

	public void setId(Object id) {
		this.id = id;
	}

	public Object getPId() {
		return pId;
	}

	public void setPId(Object pId) {
		this.pId = pId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Boolean getOpen() {
		return open;
	}

	public void setOpen(Boolean open) {
		this.open = open;
	}

	public Boolean getNocheck() {
		return nocheck;
	}

	public void setNocheck(Boolean nocheck) {
		this.nocheck = nocheck;
	}

	public boolean isChecked() {
		return checked;
	}

	public void setChecked(Boolean checked) {
		this.checked = checked;
	}
	
	public List<ZtreeObj> getSubNode() {
		return subNode;
	}

	public void setSubNode(List<ZtreeObj> subNode) {
		this.subNode = subNode;
	}
	
	

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public Boolean getDisable() {
		return disable;
	}

	public void setDisable(Boolean disable) {
		this.disable = disable;
	}

	public Map<String,Object> getMap(){
		Map<String,Object> map = new HashMap<>();
		map.put("id",String.valueOf(id));
		map.put("pId",String.valueOf(pId));
		map.put("name", this.getName());
		map.put("open", this.getOpen());
		map.put("nocheck", this.getNocheck());
		map.put("checked", this.isChecked());
		map.put("desc", this.getDesc());
		map.put("disable", this.getDisable());
		return map;
	}
	
}
