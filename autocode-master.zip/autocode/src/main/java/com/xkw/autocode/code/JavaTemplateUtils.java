package com.xkw.autocode.code;

import java.util.List;

import com.xkw.autocode.jdbc.entity.ColumnEntity;

/**
 * 生成java get&set的方法
 * 
 * @author xiangkaiwei
 *
 */
public class JavaTemplateUtils {

	private JavaTemplateUtils() {
	}

	private static final String T_KEY = "\t/**";

	private static final String T_KEY2 = "\t * ";

	/**
	 * 获取java类属性的定义
	 * 
	 * @param columns
	 *            属性集合
	 */
	public static String getJavaProperty(List<ColumnEntity> columns) {
		StringBuilder sbl = new StringBuilder();

		for (ColumnEntity column : columns) {

			if (column.getColumnName().equalsIgnoreCase("id")) {
				continue;
			}

			// java 中数据类型
			String javaType = CodeUtils.getJavaType(column.getJdbcType());

			// 属性名
			String attrName = CodeUtils.getAttrName(column.getColumnName());

			// 注释
			String desc = column.getComments();

			sbl.append(T_KEY).append("\n");
			sbl.append(T_KEY2).append(desc).append("\n");
			sbl.append("\t*/").append("\n");
			sbl.append("\tprivate " + javaType + " " + attrName).append(";\n");
			sbl.append("\n");
		}

		return sbl.toString();
	}

	/**
	 * 生成get&set方法
	 * 
	 * @param columns
	 *            属性集合
	 */
	public static String getJavaPropertyGetSet(List<ColumnEntity> columns) {

		StringBuilder sbl = new StringBuilder();

		for (ColumnEntity column : columns) {

			String columnName = column.getColumnName();

			if (columnName.equalsIgnoreCase("id")) {
				continue;
			}

			// java 中数据类型
			String javaType = CodeUtils.getJavaType(column.getJdbcType());

			// 属性名
			String attrName = CodeUtils.getAttrName(columnName);

			// 首字母变大写的属性名
			String upAttrName = CodeUtils.getUpAttr(attrName);

			// 注释
			String desc = column.getComments();

			sbl.append(T_KEY).append("\n");
			sbl.append(T_KEY2).append("GET.").append(desc).append("\n");
			sbl.append("\t*/").append("\n");
			sbl.append("\tpublic " + javaType + " get" + upAttrName).append("(){\n");
			sbl.append("\t\treturn this.").append(attrName).append(";\n");
			sbl.append("\t}").append("\n").append("\n");

			sbl.append(T_KEY).append("\n");
			sbl.append(T_KEY2).append("SET.").append(desc).append("\n");
			sbl.append("\t*/").append("\n");
			sbl.append("\tpublic void set" + upAttrName).append("(" + javaType + " " + attrName + "){\n");
			sbl.append("\t\t this.").append(attrName).append("=").append(attrName).append(";\n");
			sbl.append("\t}").append("\n").append("\n");
		}

		return sbl.toString();
	}

}
