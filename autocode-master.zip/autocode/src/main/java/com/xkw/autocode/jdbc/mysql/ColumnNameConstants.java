package com.xkw.autocode.jdbc.mysql;

/**
 * 列名常量
 * 
 * @author xiangkaiwei
 *
 */
public class ColumnNameConstants {
	
	

	public static final String TABLE_NAME = "TABLE_NAME"; // 表名
	public static final String TABLE_COMMENT = "TABLE_COMMENT"; // 表名注释

	public static final String COLUMN_NAME = "COLUMN_NAME"; // 字段名
	public static final String COLUMN_TYPE = "COLUMN_TYPE"; // 字段类型
	public static final String COLUMN_COMMENT = "COLUMN_COMMENT"; // 字段注释
	public static final String COLUMN_DEFAULT = "COLUMN_DEFAULT"; //
	public static final String COLUMN_KEY = "COLUMN_KEY"; //

	private ColumnNameConstants() {}
}
