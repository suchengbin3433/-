package com.xkw.autocode.service;

import java.util.List;

import com.github.pagehelper.PageInfo;
import com.xkw.autocode.util.PageVo;
import com.xkw.autocode.vo.TemplateConfigDetailVo;

/**
 * “模板配置详情表”	业务对内接口类
 * @author auto
*/
public interface TemplateConfigDetailService{

	/**
	 * 新增接口
	 * @param templateConfigDetailVo
	 * @return
	*/
	public int insert(TemplateConfigDetailVo templateConfigDetailVo);

	/**
	 * 根据ID删除接口
	 * @param id
	 * @return
	*/
	public int delete(Long id);

	/**
	 * 根据ID更新接口
	 * @param templateConfigDetailVo
	 * @return
	*/
	public int update(TemplateConfigDetailVo templateConfigDetailVo);

	/**
	 * 根据ID查找接口
	 * @param id
	 * @return
	*/
	public TemplateConfigDetailVo findById(Long id);
	
	/**
	 * 根据ID查找接口
	 * @param id
	 * @return
	*/
	public List<TemplateConfigDetailVo> findByTemplateId(Long templateId);
	
	/**
	 * 分页查找接口（可带分页条件）
	 * @param templateConfigDetailVo
	 * @param page
	 * @return
	*/
	public PageInfo<TemplateConfigDetailVo> findByPage(TemplateConfigDetailVo templateConfigDetailVo,PageVo page);

	/**
	 * 根据模板ID删除模板文件
	 * @param templateId
	 * @return
	 */
	public int deleteByTemplateId(Long templateId);

}

