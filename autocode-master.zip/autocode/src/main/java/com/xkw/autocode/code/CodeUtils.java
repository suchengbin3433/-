package com.xkw.autocode.code;

public class CodeUtils {
	
	private CodeUtils() {}

	/**
	 * 首字母变小写
	 */
	public static String getLowAttr(String attr) {
		return attr.substring(0, 1).toLowerCase() + attr.substring(1);
	}

	/**
	 * 首字母变大写
	 */
	public static String getUpAttr(String attr) {
		return attr.substring(0, 1).toUpperCase() + attr.substring(1);
	}

	/**
	 * 表名变成类名
	 */
	public static String getClassName(String tableName) {
		tableName = tableName.toUpperCase();
		if (tableName.startsWith("TB_") || tableName.startsWith("DB_")) {
			tableName = tableName.substring(3);
		}
		if (tableName.startsWith("VIP_") || tableName.startsWith("APP_") || tableName.startsWith("CMS_")) {
			tableName = tableName.substring(4);
		}

		String[] ts = tableName.split("_");
		StringBuilder result = new StringBuilder();
		for (String xs : ts) {
			result.append(xs.substring(0, 1).toUpperCase()).append(xs.substring(1).toLowerCase());
		}
		return result.toString();
	}

	/**
	 * 表字段名变属性名
	 */
	public static String getAttrName(String columnName) {
		columnName = columnName.toUpperCase();

		String[] ts = columnName.split("_");
		StringBuilder result = new StringBuilder();
		for (String xs : ts) {
			result.append(xs.substring(0, 1).toUpperCase()).append(xs.substring(1).toLowerCase());
		}

		return getLowAttr(result.toString());
	}

	/**
	 * 数据库数据类型映射java数据类型
	 * 
	 * @param jdbcType
	 * @return
	 */
	public static String getJavaType(String jdbcType) {
		jdbcType = jdbcType.toUpperCase();
		if (jdbcType.startsWith("VARCHAR") || jdbcType.startsWith("TEXT") || jdbcType.startsWith("MEDIUMTEXT")
				|| jdbcType.startsWith("CHAR")) {
			return "String";
		} else if (jdbcType.startsWith("BIGINT")) {
			return "Long";
		} else if (jdbcType.startsWith("INT") || jdbcType.startsWith("TINYINT")) {
			return "Integer";
		} else if (jdbcType.startsWith("DOUBLE")) {
			return "Double";
		}

		return "";
	}

	public static String getSqlInsertColumn(String attrName, String columnName) {
		StringBuilder sbl = new StringBuilder();
		sbl.append("\t\t").append("<if test=\"" + attrName + " != null\" >").append("\n\t\t\t").append(columnName)
				.append(",\n\t\t</if>\n");
		return sbl.toString();
	}

	public static String getSqlInsertValue(String attrName, String columnName, String jdbcType) {
		StringBuilder sbl = new StringBuilder();
		sbl.append("\t\t").append("<if test=\"" + attrName + " != null\" >").append("\n\t\t\t")
				.append("#{" + attrName );
		
		if(jdbcType != null && !"".equals(jdbcType)){
			sbl.append(",jdbcType=" + jdbcType);
		}
		sbl.append("}").append(",\n\t\t</if>\n");
		
		return sbl.toString();
	}

	public static String getSqlUpdateColumn(String attrName, String columnName, String jdbcType) {
		StringBuilder sbl = new StringBuilder();
		
		sbl.append("\t\t").append("<if test=\"" + attrName + " != null\" >").append("\n\t\t\t")
				.append(columnName + " = #{" + attrName );
		if(jdbcType != null && !"".equals(jdbcType)){
			sbl.append(",jdbcType=" + jdbcType);
		}
						
		sbl.append("}").append(",\n\t\t</if>\n");
		return sbl.toString();
	}

	public static String getSqlWhere(String attrName, String columnName, String jdbcType) {
		StringBuilder sbl = new StringBuilder();
		if (jdbcType != null && jdbcType.equals("VARCHAR")) {
			sbl.append("\t\t").append("<if test=\"" + attrName + " != null and " + attrName + " != ''\" >")
					.append("\n\t\t\t").append("AND " + columnName + " LIKE CONCAT('%',TRIM(#{" + attrName + "}),'%' )")
					.append("\n\t\t</if>\n");
		} else {
			sbl.append("\t\t").append("<if test=\"" + attrName + " != null\" >").append("\n\t\t\t")
					.append("AND " + columnName + " = #{" + attrName);
			if(jdbcType != null && !"".equals(jdbcType)){
				sbl.append(",jdbcType=" + jdbcType);
			}	
			sbl.append("}").append("\n\t\t</if>\n");
		}
		return sbl.toString();
	}
}
