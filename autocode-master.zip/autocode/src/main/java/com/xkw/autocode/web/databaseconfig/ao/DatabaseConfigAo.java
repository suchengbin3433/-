package com.xkw.autocode.web.databaseconfig.ao;

import java.util.List;

import com.github.pagehelper.PageInfo;
import com.xkw.autocode.vo.DatabaseConfigVo;

/**
 * “数据库配置表”	Ao接口类
 * @author auto
*/
public interface DatabaseConfigAo {
	
	/**
	 * 新增操作
	 * @param  configVo
	 * @return
	 */
	public Boolean insertDatabaseConfig(DatabaseConfigVo configVo);
	
	/**
	 * 删除操作
	 * @param  id
	 * @return
	 */
	public Boolean deleteDatabaseConfig(Long id);
	
	/**
	 * 修改操作
	 * @param  configVo
	 * @return
	 */
	public Boolean updateDatabaseConfig(DatabaseConfigVo configVo);
	
	/**
	 * 根据ID查询
	 * @param  id
	 * @return
	 */
	public DatabaseConfigVo queryById(Long id);
	
	/**
	 * 列表查询
	 * @param configVo
	 * @param pageNo
	 * @param pageSize
	 * @param orderBy
	 * @return
	 */
	public PageInfo<DatabaseConfigVo> queryByPage(DatabaseConfigVo configVo,Integer pageNo,Integer pageSize,String orderBy);
	
	/**
	 * 查询列表
	 * @param configVo
	 * @return
	 */
	public List<DatabaseConfigVo> queryList(DatabaseConfigVo configVo);

}
