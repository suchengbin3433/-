package com.xkw.autocode;

import java.io.File;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component   
public class PropertiesConfig {
	
private static final String TEMPLATE = "template";
	
	private static final String CODEDEMO = "codedemo";
	
	@Value("${server.tomcat.basedir}")
	private String basedir;
	
	/**
	 * 获取代码模板
	 * @return
	 */
	public String getCodeTemplateDir() {
		String dir = basedir;
		if(!dir.endsWith(File.separator)) {
			dir += File.separator;
		}
		dir += TEMPLATE;
		return dir;
	}
	
	/**
	 * 获取示例代码路径
	 * @return
	 */
	public String getCodeDemoDir() {
		String dir = basedir;
		if(!dir.endsWith(File.separator)) {
			dir += File.separator;
		}
		dir += CODEDEMO;
		return dir;
	}
}
