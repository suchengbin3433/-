package com.xkw.autocode.web.databaseconfig.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.github.pagehelper.PageInfo;
import com.xkw.autocode.base.BaseController;
import com.xkw.autocode.util.PageUtils;
import com.xkw.autocode.util.QueryUtils;
import com.xkw.autocode.vo.DatabaseConfigVo;
import com.xkw.autocode.web.common.Result;
import com.xkw.autocode.web.databaseconfig.DatabaseConfigUrlUtil;
import com.xkw.autocode.web.databaseconfig.ao.DatabaseConfigAo;

/**
 * “数据库配置表” Controller类
 * 
 * @author auto
 */
@Controller
public class DatabaseConfigController extends BaseController {

	@Autowired
	private DatabaseConfigAo databaseConfigAo;

	/**
	 * 跳转到列表页面
	 */
	@RequestMapping(value = DatabaseConfigUrlUtil.LIST)
	public ModelAndView list() {
		ModelAndView modelAndView = new ModelAndView();

		modelAndView.setViewName("databaseConfig/list");
		return modelAndView;
	}

	/**
	 * 获取列表页面的数据
	 */
	@RequestMapping(value = DatabaseConfigUrlUtil.LIST_DATA)
	@ResponseBody
	public Result listData(HttpServletRequest request, DatabaseConfigVo configVo) {

		QueryUtils query = QueryUtils.newInstance(request);

		PageInfo<DatabaseConfigVo> pageInfo = databaseConfigAo.queryByPage(configVo, query.getPageNo(),
				query.getPageSize(), query.getOrderBy());

		return Result.ok().put("page", new PageUtils(pageInfo));

	}

	/**
	 * 删除操作
	 */
	@RequestMapping(value = DatabaseConfigUrlUtil.DO_DELETE)
	@ResponseBody
	public Object doDelete(@RequestBody Long[] ids) {

		if (ids != null && ids.length > 0) {

			for (Long id : ids) {
				databaseConfigAo.deleteDatabaseConfig(id);
			}
		}
		return Result.ok();
	}

	/**
	 * 跳转到修改页面
	 */
	@RequestMapping(value = DatabaseConfigUrlUtil.TO_MODIFY)
	@ResponseBody
	public Result toModify(Long id) {

		return Result.ok().put("databaseConfig", databaseConfigAo.queryById(id));
	}

	/**
	 * 新增操作
	 */
	@RequestMapping(value = DatabaseConfigUrlUtil.DO_ADD)
	@ResponseBody
	public Object doAdd(@RequestBody DatabaseConfigVo config) {
		return doAddOrModify(config);
	}

	/**
	 * 编辑操作
	 */
	@RequestMapping(value = DatabaseConfigUrlUtil.DO_MODIFY)
	@ResponseBody
	public Object doModify(@RequestBody DatabaseConfigVo config) {
		return doAddOrModify(config);
	}

	/**
	 * 新增或者编辑操作
	 */
	private Object doAddOrModify(DatabaseConfigVo config) {
		boolean result = false;
		if (config != null) {
			if (config.getId() != null) {
				result = databaseConfigAo.updateDatabaseConfig(config);
			} else {
				result = databaseConfigAo.insertDatabaseConfig(config);
			}
		}
		if (result) {
			return Result.ok();
		} else {
			return Result.ok("操作失败");
		}
	}
}
