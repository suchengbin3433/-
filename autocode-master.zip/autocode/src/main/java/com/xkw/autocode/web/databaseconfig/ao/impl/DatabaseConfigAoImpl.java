package com.xkw.autocode.web.databaseconfig.ao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageInfo;
import com.xkw.autocode.service.DatabaseConfigService;
import com.xkw.autocode.util.PageVo;
import com.xkw.autocode.vo.DatabaseConfigVo;
import com.xkw.autocode.web.databaseconfig.ao.DatabaseConfigAo;

/**
 * “数据库配置表”	Ao实现类
 * @author auto
*/
@Service("databaseConfigAo")
public class DatabaseConfigAoImpl implements DatabaseConfigAo {
	
	@Autowired
	private DatabaseConfigService databaseConfigService;

	/**
	 * 新增操作
	 */
	@Override
	public Boolean insertDatabaseConfig(DatabaseConfigVo config){
		if(config == null){
			return false;
		}
		
		int result = databaseConfigService.insert(config);
		if(result == 1){
			return true;
		}else{
			return false;
		}
	}
	
	/**
	 * 删除操作
	 */
	@Override
	public Boolean deleteDatabaseConfig(Long id){
		if(id == null){
			return false;
		}
		
		int result = databaseConfigService.delete(id);
		if(result == 1){
			return true;
		}else{
			return false;
		}
	}
	
	/**
	 * 修改操作
	 */
	@Override
	public Boolean updateDatabaseConfig(DatabaseConfigVo config){
		if(config == null || config.getId() == null){
			return false;
		}
		
		int result = databaseConfigService.update(config);
		if(result > 0){
			return true;
		}else{
			return false;
		}
	}
	
	/**
	 * 根据ID查询
	 */
	@Override
	public DatabaseConfigVo queryById(Long id){
		if(id == null){
			return null;
		}
		
		return  databaseConfigService.findById(id);
	}
	
	/**
	 * 列表查询
	 */
	@Override
	public PageInfo<DatabaseConfigVo> queryByPage(DatabaseConfigVo databaseConfigVo,Integer pageNo,Integer pageSize,String orderBy){
		return databaseConfigService.findByPage(databaseConfigVo,new PageVo(pageNo, pageSize, orderBy));
	}
	
	@Override
	public List<DatabaseConfigVo> queryList(DatabaseConfigVo databaseConfigVo){
		return databaseConfigService.findByList(databaseConfigVo);
	}
}
