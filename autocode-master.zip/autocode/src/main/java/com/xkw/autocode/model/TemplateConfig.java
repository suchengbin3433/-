package com.xkw.autocode.model;

import javax.persistence.Table;

import com.xkw.autocode.base.BaseModel;

/**
 * 模板配置表
 * 
 * @author auto
 */
@Table(name = "template_config")
public class TemplateConfig extends BaseModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1861466356891113812L;

	/**
	 * 模板的名称
	 */
	private String templateName;

	/**
	 * GET.模板的名称
	 */
	public String getTemplateName() {
		return this.templateName;
	}

	/**
	 * SET.模板的名称
	 */
	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

}
