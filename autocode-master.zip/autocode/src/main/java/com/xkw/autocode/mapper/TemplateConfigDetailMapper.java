package com.xkw.autocode.mapper;

import com.xkw.autocode.base.BaseMapper;
import com.xkw.autocode.model.TemplateConfigDetail;

/**
 * “模板配置详情表” Mapper 类
 * @author auto
*/
public interface TemplateConfigDetailMapper extends BaseMapper<TemplateConfigDetail>{
	
}
