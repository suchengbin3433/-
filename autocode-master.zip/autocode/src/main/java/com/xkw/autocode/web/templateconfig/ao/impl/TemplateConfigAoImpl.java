package com.xkw.autocode.web.templateconfig.ao.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xkw.autocode.service.TemplateConfigDetailService;
import com.xkw.autocode.service.TemplateConfigService;
import com.xkw.autocode.vo.TemplateConfigDetailVo;
import com.xkw.autocode.vo.TemplateConfigVo;
import com.xkw.autocode.web.templateconfig.ao.TemplateConfigAo;

/**
 * “模板配置表”	Ao实现类
 * @author auto
*/
@Service("templateConfigAo")
public class TemplateConfigAoImpl implements TemplateConfigAo {
	
	@Autowired
	private TemplateConfigService templateConfigService;
	
	@Autowired
	private TemplateConfigDetailService templateConfigDetailService;

	/**
	 * 新增操作
	 */
	@Override
	public Boolean insertTemplateConfig(TemplateConfigVo templateConfig){
		if(templateConfig == null){
			return false;
		}
		
		int result = templateConfigService.insert(templateConfig);
		if(result == 1){
			return true;
		}else{
			return false;
		}
	}
	
	/**
	 * 删除操作
	 */
	@Override
	public Boolean deleteTemplateConfig(Long id){
		if(id == null){
			return false;
		}
		
		int result = templateConfigService.delete(id);
		if(result == 1){
			return true;
		}else{
			return false;
		}
	}
	
	/**
	 * 修改操作
	 */
	@Override
	public Boolean updateTemplateConfig(TemplateConfigVo templateConfig){
		if(templateConfig == null || templateConfig.getId() == null){
			return false;
		}
		
		int result = templateConfigService.update(templateConfig);
		if(result > 0){
			return true;
		}else{
			return false;
		}
	}
	
	/**
	 * 根据ID查询
	 */
	@Override
	public TemplateConfigVo queryById(Long id){
		if(id == null){
			return null;
		}
		
		return  templateConfigService.findById(id);
	}
	
	@Override
	public List<TemplateConfigVo> queryAll(){
		return templateConfigService.findByList(new TemplateConfigVo());
	}
	
	/**
	 * 列表查询
	 */
	@Override
	public List<Map<String,Object>> queryByPage(TemplateConfigVo templateConfig){
		
		List<Map<String,Object>> resultList = new ArrayList<>();
		
		List<TemplateConfigVo> templateConfigList = templateConfigService.findByList(templateConfig);
		
		if(templateConfigList != null && !templateConfigList.isEmpty()) {
			
			for(TemplateConfigVo templateConfigVo : templateConfigList) {
				resultList.add(getTemplateConfigMap(templateConfigVo));
				
				List<TemplateConfigDetailVo> details = templateConfigDetailService.findByTemplateId(templateConfigVo.getId());
				
				if(details != null && !details.isEmpty()) {
					for(TemplateConfigDetailVo vo : details) {
						resultList.add(getTemplateConfigDetailMap(vo,templateConfigVo.getId()));
					}
				}
			}
		}
		
		return resultList;
	}
	
	private Map<String, Object> getTemplateConfigDetailMap(TemplateConfigDetailVo vo, Long id) {
		Map<String,Object> map = new HashMap<>();
		
		map.put("id", "s" + vo.getId());
		map.put("name", vo.getTemplateFileName());
		map.put("path", vo.getTemplatePath());
		map.put("type", vo.getTemplateType());
		map.put("parentId", id);
		
		return map;
	}

	private Map<String,Object> getTemplateConfigMap(TemplateConfigVo templateConfigVo){
		Map<String,Object> map = new HashMap<>();
		
		map.put("id", templateConfigVo.getId());
		map.put("name", templateConfigVo.getTemplateName());
		map.put("path", "");
		map.put("parentId", 0);
		return map;
	}
}
