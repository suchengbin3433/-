package com.xkw.autocode.vo;

import com.xkw.autocode.base.BaseVo;

/**
 * 数据库和java的类型映射配置
 * @author auto
*/
public class DataTypeConfigVo extends BaseVo  {

	private static final long serialVersionUID = 1L;

	/**
	 * 数据库分类
	*/
	private String dbType;

	/**
	 * JDBC的类型
	*/
	private String jdbcType;

	/**
	 * JAVA的类型
	*/
	private String javaType;

	/**
	 * JAVA类型的包路径
	*/
	private String javaPackage;

	/**
	 * GET.数据库分类
	*/
	public String getDbType(){
		return this.dbType;
	}

	/**
	 * SET.数据库分类
	*/
	public void setDbType(String dbType){
		 this.dbType=dbType;
	}

	/**
	 * GET.JDBC的类型
	*/
	public String getJdbcType(){
		return this.jdbcType;
	}

	/**
	 * SET.JDBC的类型
	*/
	public void setJdbcType(String jdbcType){
		 this.jdbcType=jdbcType;
	}

	/**
	 * GET.JAVA的类型
	*/
	public String getJavaType(){
		return this.javaType;
	}

	/**
	 * SET.JAVA的类型
	*/
	public void setJavaType(String javaType){
		 this.javaType=javaType;
	}

	/**
	 * GET.JAVA类型的包路径
	*/
	public String getJavaPackage(){
		return this.javaPackage;
	}

	/**
	 * SET.JAVA类型的包路径
	*/
	public void setJavaPackage(String javaPackage){
		 this.javaPackage=javaPackage;
	}



}


