package com.xkw.autocode.web.datatypeconfig.ao;

import java.util.List;

import com.github.pagehelper.PageInfo;
import com.xkw.autocode.vo.DataTypeConfigVo;

/**
 * “数据库和java的类型映射配置” Ao接口类
 * 
 * @author auto
 */
public interface DataTypeConfigAo {

	/**
	 * 新增操作
	 * 
	 * @param dataTypeConfigVo
	 * @return
	 */
	Boolean insertDataTypeConfig(DataTypeConfigVo dataTypeConfigVo);

	/**
	 * 删除操作
	 * 
	 * @param id
	 * @return
	 */
	Boolean deleteDataTypeConfig(Long id);

	/**
	 * 修改操作
	 * 
	 * @param dataTypeConfigVo
	 * @return
	 */
	Boolean updateDataTypeConfig(DataTypeConfigVo dataTypeConfigVo);

	/**
	 * 根据ID查询
	 * 
	 * @param id
	 * @return
	 */
	DataTypeConfigVo queryById(Long id);

	/**
	 * 列表查询
	 * 
	 * @param dataTypeConfigVo
	 * @return
	 */
	List<DataTypeConfigVo> findList(DataTypeConfigVo dataTypeConfigVo);

	/**
	 * 分页查询
	 * 
	 * @param dataTypeConfigVo
	 * @param pageNo
	 * @param pageSize
	 * @param orderBy
	 * @return
	 */
	PageInfo<DataTypeConfigVo> queryByPage(DataTypeConfigVo dataTypeConfigVo, Integer pageNo, Integer pageSize,
			String orderBy);

}
