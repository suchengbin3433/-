package com.xkw.autocode.service.impl;

import java.util.Collections;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.xkw.autocode.mapper.TemplateConfigMapper;
import com.xkw.autocode.model.TemplateConfig;
import com.xkw.autocode.service.TemplateConfigDetailService;
import com.xkw.autocode.service.TemplateConfigService;
import com.xkw.autocode.util.ExampleUtils;
import com.xkw.autocode.util.ObjectCopyUtils;
import com.xkw.autocode.vo.TemplateConfigVo;

import tk.mybatis.mapper.entity.Example;

/**
 * “模板配置表”	业务类
 * @author auto
*/
@Service("templateConfigVoService")
public class TemplateConfigServiceImpl implements TemplateConfigService{

	private static final Logger logger = LoggerFactory.getLogger(TemplateConfigServiceImpl.class);
	
	@Autowired
	private TemplateConfigMapper templateConfigDao;

	@Autowired
	private TemplateConfigDetailService templateConfigDetailService;
	
	/**
	 * 新增操作
	*/
	@Override
	public int insert(TemplateConfigVo templateConfigVo){
		if(templateConfigVo == null){
			return 0;
		}
		
		TemplateConfig templateConfig = this.getTemplateConfig(templateConfigVo);
		if(templateConfig == null) {
			return 0;
		}
		
		return this.templateConfigDao.insertSelective(templateConfig);
	}

	/**
	 * 根据ID删除操作
	*/
	@Transactional
	@Override
	public int delete(Long id){
		if(id == null || id <= 0){
			return 0;
		}
		//删除模板文件
		templateConfigDetailService.deleteByTemplateId(id);
		
		return this.templateConfigDao.deleteByPrimaryKey(id);
	}

	/**
	 * 根据ID更新操作
	*/
	@Override
	public int update(TemplateConfigVo templateConfigVo){
		if(templateConfigVo == null || templateConfigVo.getId() == null){
			return 0;
		}
		
		TemplateConfig templateConfig = this.getTemplateConfig(templateConfigVo);
		if(templateConfig == null) {
			return 0;
		}
		
		return this.templateConfigDao.updateByPrimaryKeySelective(templateConfig);
	}

	/**
	 * 根据ID查找操作
	*/
	@Override
	public TemplateConfigVo findById(Long id){
		if(id == null || id <= 0){
			return null;
		}
		TemplateConfig templateConfig = this.templateConfigDao.selectByPrimaryKey(id);
		
		try {
			return (TemplateConfigVo) ObjectCopyUtils.copyProperties(templateConfig, TemplateConfigVo.class);
		} catch (ReflectiveOperationException e) {
			logger.error("",e);
			return null;
		}
	}

	/**
	 * 分页查找接口
	*/
	@SuppressWarnings("unchecked")
	@Override
	public List<TemplateConfigVo> findByList(TemplateConfigVo templateConfigVo){
		
		TemplateConfig templateConfig = this.getTemplateConfig(templateConfigVo);
		if(templateConfig == null) {
			return Collections.emptyList();
		}
		
		Example example = ExampleUtils.getExampleFromObject(templateConfig);
		
		List<TemplateConfig> list = this.templateConfigDao.selectByExample(example);
		try {
			return ObjectCopyUtils.copyPropertiesList(list, TemplateConfigVo.class);
		} catch (ReflectiveOperationException e) {
			logger.error("", e);
			return Collections.emptyList();
		}
		
	}
	
	private TemplateConfig getTemplateConfig(TemplateConfigVo templateConfigVo) {
		try {
			return (TemplateConfig) ObjectCopyUtils.copyProperties(templateConfigVo, TemplateConfig.class);
		} catch (ReflectiveOperationException e) {
			logger.error("",e);
			return null;
		}
	}
}
