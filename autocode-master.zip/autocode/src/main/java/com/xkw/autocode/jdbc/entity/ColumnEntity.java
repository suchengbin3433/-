package com.xkw.autocode.jdbc.entity;

/**
 * 字段属性
 */
public class ColumnEntity {
	
	// 列名
	private String columnName;
	
	// 列名类型
	private String jdbcType;
	
	// 列名备注
	private String comments;

	public ColumnEntity(String columnName, String jdbcType, String comments) {
		super();
		this.columnName = columnName;
		this.jdbcType = jdbcType;
		this.comments = comments;
	}

	public ColumnEntity() {
		super();
	}

	public String getColumnName() {
		return columnName;
	}

	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}

	public String getJdbcType() {
		return jdbcType;
	}

	public void setJdbcType(String jdbcType) {
		this.jdbcType = jdbcType;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

}
