package com.xkw.autocode.service.impl;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.xkw.autocode.mapper.UserConfigMapper;
import com.xkw.autocode.model.UserConfig;
import com.xkw.autocode.service.UserConfigService;
import com.xkw.autocode.util.ExampleUtils;
import com.xkw.autocode.util.ObjectCopyUtils;
import com.xkw.autocode.util.PageVo;
import com.xkw.autocode.vo.UserConfigVo;

import tk.mybatis.mapper.entity.Example;

/**
 * “用户配置表” 业务类
 * 
 * @author auto
 */
@Service("userConfigService")
public class UserConfigServiceImpl implements UserConfigService {

	private static final Logger logger = LoggerFactory.getLogger(UserConfigServiceImpl.class);

	@Autowired
	private UserConfigMapper userConfigDao;

	/**
	 * 新增操作
	 */
	@Override
	public int insert(UserConfigVo userConfigVo) {
		if (userConfigVo == null) {
			return 0;
		}

		UserConfig userConfig = this.getUserConfig(userConfigVo);
		if (userConfig == null) {
			return 0;
		}
		return this.userConfigDao.insertSelective(userConfig);
	}

	/**
	 * 根据ID删除操作
	 */
	@Override
	public int delete(Long id) {
		if (id == null || id <= 0) {
			return 0;
		}
		return this.userConfigDao.deleteByPrimaryKey(id);
	}

	/**
	 * 根据ID更新操作
	 */
	@Override
	public int update(UserConfigVo userConfigVo) {
		if (userConfigVo == null || userConfigVo.getId() == null) {
			return 0;
		}

		UserConfig userConfig = this.getUserConfig(userConfigVo);
		if (userConfig == null) {
			return 0;
		}

		return this.userConfigDao.updateByPrimaryKeySelective(userConfig);
	}

	/**
	 * 根据ID查找操作
	 */
	@Override
	public UserConfigVo findById(Long id) {
		if (id == null || id <= 0) {
			return null;
		}
		UserConfig userConfig = this.userConfigDao.selectByPrimaryKey(id);

		try {
			return (UserConfigVo) ObjectCopyUtils.copyProperties(userConfig, UserConfigVo.class);
		} catch (ReflectiveOperationException e) {
			logger.error("", e);
			return null;
		}
	}
	
	/**
	 * 根据用户名查询
	 */
	public UserConfigVo queryByUserName(String userName) {
		if (StringUtils.isEmpty(userName)) {
			return null;
		}
		Example example = new Example(UserConfig.class);
		example.and().andEqualTo("userName", userName);
		
		UserConfig userConfig = this.userConfigDao.selectOneByExample(example);

		try {
			return (UserConfigVo) ObjectCopyUtils.copyProperties(userConfig, UserConfigVo.class);
		} catch (ReflectiveOperationException e) {
			logger.error("", e);
			return null;
		}
	}
	

	/**
	 * 分页查找接口
	 */
	@Override
	public PageInfo<UserConfigVo> findByPage(UserConfigVo userConfigVo, PageVo pageVo) {

		UserConfig userConfig = this.getUserConfig(userConfigVo);
		if (userConfig == null) {
			return null;
		}
		return this.findByPage(userConfig, pageVo.getPageNo(), pageVo.getPageSize(), pageVo.getOrderBy());
	}

	/**
	 * 分页查找
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private PageInfo<UserConfigVo> findByPage(UserConfig userConfig, int pageNo, int pageSize, String orderBy) {
		PageHelper.startPage(pageNo, pageSize);
		if (orderBy != null && orderBy.length() > 0) {
			PageHelper.orderBy(orderBy);
		}

		Example example = ExampleUtils.getExampleFromObject(userConfig);

		List<UserConfig> list = this.userConfigDao.selectByExample(example);
		try {
			
			PageInfo pageInfo = new PageInfo<>(list);
			pageInfo.setList(ObjectCopyUtils.copyPropertiesList(list, UserConfigVo.class));
			return pageInfo;
		} catch (ReflectiveOperationException e) {
			logger.error("", e);
			return null;
		}
	}

	private UserConfig getUserConfig(UserConfigVo userConfigVo) {
		try {
			return (UserConfig) ObjectCopyUtils.copyProperties(userConfigVo, UserConfig.class);
		} catch (ReflectiveOperationException e) {
			logger.error("", e);
			return null;
		}
	}
}
