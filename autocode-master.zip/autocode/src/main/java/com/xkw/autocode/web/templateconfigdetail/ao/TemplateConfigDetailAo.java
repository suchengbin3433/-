package com.xkw.autocode.web.templateconfigdetail.ao;

import com.xkw.autocode.vo.TemplateConfigDetailVo;

/**
 * “模板配置详情表”	Ao接口类
 * @author auto
*/
public interface TemplateConfigDetailAo {
	
	/**
	 * 新增操作
	 * @param  templateConfigDetailVo
	 * @return
	 */
	public Boolean insertTemplateConfigDetail(TemplateConfigDetailVo templateConfigDetailVo);
	
	/**
	 * 删除操作
	 * @param  id
	 * @return
	 */
	public Boolean deleteTemplateConfigDetail(Long id);
	
	/**
	 * 修改操作
	 * @param  templateConfigDetailVo
	 * @return
	 */
	public Boolean updateTemplateConfigDetail(TemplateConfigDetailVo templateConfigDetailVo);
	
	/**
	 * 根据ID查询
	 * @param  id
	 * @return
	 */
	public TemplateConfigDetailVo queryById(Long id);

}
