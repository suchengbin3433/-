package com.xkw.autocode.web.templateconfig;

import com.xkw.autocode.base.BaseURL;

/**
 * 模板配置表 请求地址
 * 
 * @author auto
 */
public class TemplateConfigUrlUtil extends BaseURL {

	/** 列表 */
	public static final String LIST = "/templateConfig/list" + DYNAMIC_WEB_SUFFIX;
	public static final String LIST_DATA = "/templateConfig/listData" + DYNAMIC_WEB_SUFFIX;

	/** 新增 */
	public static final String DO_ADD = "/templateConfig/doAdd" + DYNAMIC_WEB_SUFFIX;

	/** 修改 */
	public static final String TO_MODIFY = "/templateConfig/toModify" + DYNAMIC_WEB_SUFFIX;
	public static final String DO_MODIFY = "/templateConfig/doModify" + DYNAMIC_WEB_SUFFIX;

	/** 删除 */
	public static final String DO_DELETE = "/templateConfig/delete" + DYNAMIC_WEB_SUFFIX;
}
