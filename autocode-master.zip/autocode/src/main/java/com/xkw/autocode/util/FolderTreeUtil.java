package com.xkw.autocode.util;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class FolderTreeUtil {

	private static int firstPId = 9999;
	private static int firstId = 0;
	
	private FolderTreeUtil() {}

	public static List<Map<String, Object>> getTrees(String path) {

		List<Map<String, Object>> resultList = new ArrayList<>();

		File file = new File(path);
		if (!file.exists()) {
			return resultList;
		}

		setFile(resultList, file, firstId, firstPId);

		return resultList;
	}

	private static int setFile(List<Map<String, Object>> resultList, File file, int id, int pid) {

		if (file.isFile()) {
			if(!file.getName().equalsIgnoreCase("readme")) {
				ZtreeObj obj = new ZtreeObj(++id, pid, file.getName(), false, false, false);
				obj.setDesc(file.getAbsolutePath());
				resultList.add(obj.getMap());
			}
		} else {
			File[] files = file.listFiles();

			int thisId = ++id;
			ZtreeObj obj = new ZtreeObj(thisId, pid, file.getName(), true, false, false);
			resultList.add(obj.getMap());

			pid = thisId;
			for (File f : files) {
				thisId = setFile(resultList, f, thisId, pid);
			}
			
			id = thisId;
		}
		return id;
	}
}
