package com.xkw.autocode.service;

import com.github.pagehelper.PageInfo;
import com.xkw.autocode.util.PageVo;
import com.xkw.autocode.vo.UserConfigVo;

/**
 * “用户配置表”	业务对内接口类
 * @author auto
*/
public interface UserConfigService{

	/**
	 * 新增接口
	 * @param userConfigVo
	 * @return
	*/
	public int insert(UserConfigVo userConfigVo);

	/**
	 * 根据ID删除接口
	 * @param id
	 * @return
	*/
	public int delete(Long id);

	/**
	 * 根据ID更新接口
	 * @param userConfigVo
	 * @return
	*/
	public int update(UserConfigVo userConfigVo);

	/**
	 * 根据ID查找接口
	 * @param id
	 * @return
	*/
	public UserConfigVo findById(Long id);
	
	/**
	 * 根据用户名查询
	 * @param userName
	 * @return
	 */
	public UserConfigVo queryByUserName(String userName);
	
	/**
	 * 分页查找接口（可带分页条件）
	 * @param userConfigVo
	 * @param page
	 * @return
	*/
	public PageInfo<UserConfigVo> findByPage(UserConfigVo userConfigVo,PageVo page);

	

}

