package com.xkw.autocode.model;

import javax.persistence.Table;

import com.xkw.autocode.base.BaseModel;

/**
 * 用户配置表
 * @author auto
*/
@Table(name="user_config")
public class UserConfig extends BaseModel  {

	/**
	 * 
	 */
	private static final long serialVersionUID = -9199497863986552401L;

	/**
     * 用户类型：0-普遍用户，1-管理员
    */
    private Integer userType;
    
	/**
	 * 登录用户名
	*/
	private String userName;

	/**
	 * 登录密码
	*/
	private String password;

	/**
	 * 昵称
	*/
	private String nikeName;

	/**
	 * 登录次数
	*/
	private Integer loginTimes;

	/**
	 * 最后登录时间
	*/
	private Long lastLoginTime;

	/**
	 * 最后登录IP
	*/
	private String lastLoginIp;

	/**
     * GET.用户类型：0-普遍用户，1-管理员
    */
    public Integer getUserType(){
        return this.userType;
    }
 
    /**
     * SET.用户类型：0-普遍用户，1-管理员
    */
    public void setUserType(Integer userType){
         this.userType=userType;
    }
    
	/**
	 * GET.登录用户名
	*/
	public String getUserName(){
		return this.userName;
	}

	/**
	 * SET.登录用户名
	*/
	public void setUserName(String userName){
		 this.userName=userName;
	}

	/**
	 * GET.登录密码
	*/
	public String getPassword(){
		return this.password;
	}

	/**
	 * SET.登录密码
	*/
	public void setPassword(String password){
		 this.password=password;
	}

	/**
	 * GET.昵称
	*/
	public String getNikeName(){
		return this.nikeName;
	}

	/**
	 * SET.昵称
	*/
	public void setNikeName(String nikeName){
		 this.nikeName=nikeName;
	}

	/**
	 * GET.登录次数
	*/
	public Integer getLoginTimes(){
		return this.loginTimes;
	}

	/**
	 * SET.登录次数
	*/
	public void setLoginTimes(Integer loginTimes){
		 this.loginTimes=loginTimes;
	}

	/**
	 * GET.最后登录时间
	*/
	public Long getLastLoginTime(){
		return this.lastLoginTime;
	}

	/**
	 * SET.最后登录时间
	*/
	public void setLastLoginTime(Long lastLoginTime){
		 this.lastLoginTime=lastLoginTime;
	}

	/**
	 * GET.最后登录IP
	*/
	public String getLastLoginIp(){
		return this.lastLoginIp;
	}

	/**
	 * SET.最后登录IP
	*/
	public void setLastLoginIp(String lastLoginIp){
		 this.lastLoginIp=lastLoginIp;
	}



}
