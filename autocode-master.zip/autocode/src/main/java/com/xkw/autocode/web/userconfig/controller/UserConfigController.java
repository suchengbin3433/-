package com.xkw.autocode.web.userconfig.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.github.pagehelper.PageInfo;
import com.xkw.autocode.base.BaseController;
import com.xkw.autocode.util.MD5;
import com.xkw.autocode.util.PageUtils;
import com.xkw.autocode.util.QueryUtils;
import com.xkw.autocode.vo.UserConfigVo;
import com.xkw.autocode.web.common.Result;
import com.xkw.autocode.web.userconfig.UserConfigUrlUtil;
import com.xkw.autocode.web.userconfig.ao.UserConfigAo;

/**
 * “用户配置表” Controller类
 * 
 * @author auto
 */
@Controller
public class UserConfigController extends BaseController {

	@Autowired
	private UserConfigAo userConfigAo;

	/**
	 * 跳转到列表页面
	 */
	@RequestMapping(value = UserConfigUrlUtil.LIST)
	public ModelAndView list() {
		ModelAndView modelAndView = new ModelAndView();

		modelAndView.setViewName("userConfig/list");
		return modelAndView;
	}

	/**
	 * 获取列表页面的数据
	 */
	@RequestMapping(value = UserConfigUrlUtil.LIST_DATA)
	@ResponseBody
	public Result listData(HttpServletRequest request, UserConfigVo userConfigVo) {

		QueryUtils query = QueryUtils.newInstance(request);
		PageInfo<UserConfigVo> pageInfo = userConfigAo.queryByPage(userConfigVo, query.getPageNo(), query.getPageSize(),
				query.getOrderBy());

		return Result.ok().put("page", new PageUtils(pageInfo));
	}

	/**
	 * 删除操作
	 */
	@RequestMapping(value = UserConfigUrlUtil.DO_DELETE)
	@ResponseBody
	public Result doDelete(@RequestBody Long[] userIds) {

		if (userIds != null && userIds.length > 0) {

			for (Long userId : userIds) {
				userConfigAo.deleteUserConfig(userId);
			}
		}
		return Result.ok();
	}

	/**
	 * 跳转到修改页面
	 */
	@RequestMapping(value = UserConfigUrlUtil.TO_MODIFY)
	@ResponseBody
	public Result toModify(Long id) {

		return Result.ok().put("user", userConfigAo.queryById(id));
	}

	/**
	 * 新增操作
	 */
	@RequestMapping(value = UserConfigUrlUtil.DO_ADD)
	@ResponseBody
	public Object doAdd(HttpServletRequest request, @RequestBody UserConfigVo userConfig) {
		return doAddOrModify(userConfig);
	}

	/**
	 * 编辑操作
	 */
	@RequestMapping(value = UserConfigUrlUtil.DO_MODIFY)
	@ResponseBody
	public Object doModify(HttpServletRequest request, @RequestBody UserConfigVo userConfig) {
		return doAddOrModify(userConfig);
	}

	/**
	 * 新增或者编辑操作
	 */
	private Object doAddOrModify(UserConfigVo userConfig) {
		boolean result = false;
		if (userConfig != null) {
			
			if(StringUtils.isNotEmpty(userConfig.getPassword())) {
				userConfig.setPassword(MD5.md5Encode(userConfig.getPassword()));
			}
			if (userConfig.getId() != null) {
				result = userConfigAo.updateUserConfig(userConfig);
			} else {
				result = userConfigAo.insertUserConfig(userConfig);
			}
		}
		if (result) {
			return Result.ok();
		} else {
			return Result.ok("操作失败");
		}

	}
}
