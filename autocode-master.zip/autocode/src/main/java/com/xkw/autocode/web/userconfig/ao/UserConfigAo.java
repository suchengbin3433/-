package com.xkw.autocode.web.userconfig.ao;

import com.github.pagehelper.PageInfo;
import com.xkw.autocode.vo.UserConfigVo;

/**
 * “用户配置表”	Ao接口类
 * @author auto
*/
public interface UserConfigAo {
	
	/**
	 * 新增操作
	 * @param  userConfigVo
	 * @return
	 */
	public Boolean insertUserConfig(UserConfigVo userConfigVo);
	
	/**
	 * 删除操作
	 * @param  id
	 * @return
	 */
	public Boolean deleteUserConfig(Long id);
	
	/**
	 * 修改操作
	 * @param  userConfigVo
	 * @return
	 */
	public Boolean updateUserConfig(UserConfigVo userConfigVo);
	
	/**
	 * 根据ID查询
	 * @param  id
	 * @return
	 */
	public UserConfigVo queryById(Long id);
	
	/**
	 * 根据用户名查询
	 * @param  userName
	 * @return
	 */
	public UserConfigVo queryByUserName(String userName);
	
	/**
	 * 列表查询
	 * @param userConfigVo
	 * @param pageNo
	 * @param pageSize
	 * @param orderBy
	 * @return
	 */
	public PageInfo<UserConfigVo> queryByPage(UserConfigVo userConfigVo,Integer pageNo,Integer pageSize,String orderBy);

}
