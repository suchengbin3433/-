package com.xkw.autocode.web.templateconfigdetail;

import com.xkw.autocode.base.BaseURL;

/**
 * 模板配置详情表 请求地址
 * 
 * @author auto
 */
public class TemplateConfigDetailUrlUtil extends BaseURL {
	
	
	public static final String VIEW_CONTENT = "/templateConfigDetail/viewContent" + DYNAMIC_WEB_SUFFIX;
	
	public static final String DO_ADD = "/templateConfigDetail/doAdd" + DYNAMIC_WEB_SUFFIX;

	/** 修改 */
	public static final String TO_MODIFY = "/templateConfigDetail/toModify" + DYNAMIC_WEB_SUFFIX;
	public static final String DO_MODIFY = "/templateConfigDetail/doModify" + DYNAMIC_WEB_SUFFIX;

	/** 删除 */
	public static final String DO_DELETE = "/templateConfigDetail/delete" + DYNAMIC_WEB_SUFFIX;
}
