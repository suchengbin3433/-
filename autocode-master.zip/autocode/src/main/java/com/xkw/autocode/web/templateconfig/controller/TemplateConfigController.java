package com.xkw.autocode.web.templateconfig.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.xkw.autocode.base.BaseController;
import com.xkw.autocode.vo.TemplateConfigVo;
import com.xkw.autocode.web.common.Result;
import com.xkw.autocode.web.templateconfig.TemplateConfigUrlUtil;
import com.xkw.autocode.web.templateconfig.ao.TemplateConfigAo;

/**
 * “模板配置表” Controller类
 * 
 * @author auto
 */
@Controller
public class TemplateConfigController extends BaseController {

	@Autowired
	private TemplateConfigAo templateConfigAo;

	/**
	 * 跳转到列表页面
	 */
	@RequestMapping(value = TemplateConfigUrlUtil.LIST)
	public ModelAndView list() {
		ModelAndView modelAndView = new ModelAndView();

		modelAndView.setViewName("templateConfig/list");
		return modelAndView;
	}

	/**
	 * 获取列表页面的数据
	 */
	@RequestMapping(value = TemplateConfigUrlUtil.LIST_DATA)
	@ResponseBody
	public Object listData(HttpServletRequest request, TemplateConfigVo templateConfigVo) {

		return templateConfigAo.queryByPage(templateConfigVo);
	}

	/**
	 * 删除操作
	 */
	@RequestMapping(value = TemplateConfigUrlUtil.DO_DELETE)
	@ResponseBody
	public Object doDelete(Long id) {
		templateConfigAo.deleteTemplateConfig(id);
		return Result.ok();
	}

	/**
	 * 跳转到修改页面
	 */
	@RequestMapping(value = TemplateConfigUrlUtil.TO_MODIFY)
	@ResponseBody
	public Result toModify(Long id) {
		return Result.ok().put("templateConfig", templateConfigAo.queryById(id));
	}

	/**
	 * 新增操作
	 */
	@RequestMapping(value = TemplateConfigUrlUtil.DO_ADD)
	@ResponseBody
	public Object doAdd(HttpServletRequest request, @RequestBody TemplateConfigVo templateConfig) {
		return doAddOrModify(templateConfig);
	}

	/**
	 * 编辑操作
	 */
	@RequestMapping(value = TemplateConfigUrlUtil.DO_MODIFY)
	@ResponseBody
	public Object doModify(HttpServletRequest request, @RequestBody TemplateConfigVo templateConfig) {
		return doAddOrModify(templateConfig);
	}

	/**
	 * 新增或者编辑操作
	 */
	private Object doAddOrModify(TemplateConfigVo templateConfig) {
		boolean result = false;
		if (templateConfig != null) {
			if (templateConfig.getId() != null) {
				result = templateConfigAo.updateTemplateConfig(templateConfig);
			} else {
				result = templateConfigAo.insertTemplateConfig(templateConfig);
			}
		}
		if (result) {
			return Result.ok();
		} else {
			return Result.ok("操作失败");
		}
	}
}
