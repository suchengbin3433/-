package com.xkw.autocode.web.system.controller;


import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.xkw.autocode.base.BaseController;
import com.xkw.autocode.web.system.SystemUrlUtil;

/**
 * 首页
 */
@Controller
public class IndexController extends BaseController{
	
	@GetMapping(value = SystemUrlUtil.INDEX)
	public ModelAndView index() {
		ModelAndView modelAndView = new ModelAndView();
		
		modelAndView.setViewName("index");
		return modelAndView;
	}
	
	@GetMapping(value = SystemUrlUtil.MAIN)
	public ModelAndView main() {
		ModelAndView modelAndView = new ModelAndView();
		
		modelAndView.setViewName("main");
		return modelAndView;
	}
	
	@GetMapping(value = SystemUrlUtil.LOGIN)
	public ModelAndView login() {
		ModelAndView modelAndView = new ModelAndView();
		
		modelAndView.setViewName("login");
		return modelAndView;
	}
	
	@RequestMapping(value = SystemUrlUtil.NOAUTH)
	public ModelAndView noauth(HttpServletRequest request) {
		return new ModelAndView("noauth");
	}
}
