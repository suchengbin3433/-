package com.xkw.autocode.web.system;

import com.xkw.autocode.base.BaseURL;

/**
 * 数据库配置表 请求地址
 * @author auto
 */
public class SystemUrlUtil  extends BaseURL{
	
	/** 进入登录页面 */
	public static final String LOGIN = "login"+ DYNAMIC_WEB_SUFFIX ;
	
	/** 首页 */
	public static final String INDEX = "index"+ DYNAMIC_WEB_SUFFIX ;
	
	/** 主页*/
	public static final String MAIN = "main"+ DYNAMIC_WEB_SUFFIX ;
	
	/** 登录验证码*/
	public static final String LOGIN_CODE = "loginCode"+ DYNAMIC_WEB_SUFFIX ;
	
	/** 登录&登出 */
	public static final String DO_LOGIN = "doLogin"+ DYNAMIC_WEB_SUFFIX ;
	public static final String DO_LOGOUT = "doLogout"+ DYNAMIC_WEB_SUFFIX ;
	
	/** 修改密码*/
	public static final String MODIFY_CIPHER = "modifyCipher"+ DYNAMIC_WEB_SUFFIX ;
	
	/** 无权限*/
	public static final String NOAUTH = "noauth"+ DYNAMIC_WEB_SUFFIX ;
	
	/** 文件系统的操作 */
	public static final String FILE_VIEW = "fileView"+ DYNAMIC_WEB_SUFFIX ;
	public static final String FILE_TREE = "fileTree"+ DYNAMIC_WEB_SUFFIX ;
	public static final String FILE_READ = "fileRead"+ DYNAMIC_WEB_SUFFIX ;
	

}
