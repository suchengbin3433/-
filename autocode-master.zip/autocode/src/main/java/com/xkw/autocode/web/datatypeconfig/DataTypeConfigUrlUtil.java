package com.xkw.autocode.web.datatypeconfig;

import com.xkw.autocode.base.BaseURL;

/**
 * 数据库和java的类型映射配置 请求地址
 * @author auto
 */
public class DataTypeConfigUrlUtil  extends BaseURL{
	
	/** 列表 */
	public static final String LIST = "/dataTypeConfig/list"+ DYNAMIC_WEB_SUFFIX ;
	public static final String LIST_DATA = "/dataTypeConfig/listData"+ DYNAMIC_WEB_SUFFIX ;
	
	/** 新增 */
	public static final String DO_ADD = "/dataTypeConfig/doAdd"+ DYNAMIC_WEB_SUFFIX ;
	
	/** 修改 */
	public static final String TO_MODIFY = "/dataTypeConfig/toModify"+ DYNAMIC_WEB_SUFFIX ;
	public static final String DO_MODIFY = "/dataTypeConfig/doModify"+ DYNAMIC_WEB_SUFFIX ;
	
	/** 删除 */
	public static final String DO_DELETE = "/dataTypeConfig/delete"+ DYNAMIC_WEB_SUFFIX ;
}
