package com.xkw.autocode.mapper;

import com.xkw.autocode.base.BaseMapper;
import com.xkw.autocode.model.DataTypeConfig;

/**
 * “数据库和java的类型映射配置” Mapper 类
 * @author auto
*/
public interface DataTypeConfigMapper extends BaseMapper<DataTypeConfig>{
	
}
