package com.xkw.autocode.web.templateconfig.ao;

import java.util.List;
import java.util.Map;

import com.xkw.autocode.vo.TemplateConfigVo;

/**
 * “模板配置表”	Ao接口类
 * @author auto
*/
public interface TemplateConfigAo {
	
	/**
	 * 新增操作
	 * @param  templateConfigVo
	 * @return
	 */
	public Boolean insertTemplateConfig(TemplateConfigVo templateConfigVo);
	
	/**
	 * 删除操作
	 * @param  id
	 * @return
	 */
	public Boolean deleteTemplateConfig(Long id);
	
	/**
	 * 修改操作
	 * @param  templateConfigVo
	 * @return
	 */
	public Boolean updateTemplateConfig(TemplateConfigVo templateConfigVo);
	
	/**
	 * 根据ID查询
	 * @param  id
	 * @return
	 */
	public TemplateConfigVo queryById(Long id);
	
	/**
	 * 列表查询
	 * @param templateConfigVo
	 * @param pageNo
	 * @param pageSize
	 * @param orderBy
	 * @return
	 */
	public List<Map<String, Object>> queryByPage(TemplateConfigVo templateConfigVo);

	/**
	 * 查询所有模板
	 * @return
	 */
	List<TemplateConfigVo> queryAll();

}
