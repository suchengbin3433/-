package com.xkw.autocode.service.impl;

import java.util.Collections;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.xkw.autocode.mapper.DatabaseConfigMapper;
import com.xkw.autocode.model.DatabaseConfig;
import com.xkw.autocode.service.DatabaseConfigService;
import com.xkw.autocode.util.ExampleUtils;
import com.xkw.autocode.util.ObjectCopyUtils;
import com.xkw.autocode.util.PageVo;
import com.xkw.autocode.vo.DatabaseConfigVo;

import tk.mybatis.mapper.entity.Example;

/**
 * “数据库配置表” 业务类
 * 
 * @author auto
 */
@Service("databaseConfigService")
public class DatabaseConfigServiceImpl implements DatabaseConfigService {

	private static final Logger logger = LoggerFactory.getLogger(DatabaseConfigServiceImpl.class);

	@Autowired
	private DatabaseConfigMapper configDao;

	/**
	 * 新增操作
	 */
	@Override
	public int insert(DatabaseConfigVo databaseConfigVo) {
		if (databaseConfigVo == null) {
			return 0;
		}

		DatabaseConfig databaseConfig = this.getDatabaseConfig(databaseConfigVo);
		if (databaseConfig == null) {
			return 0;
		}

		return this.configDao.insertSelective(databaseConfig);

	}

	/**
	 * 根据ID删除操作
	 */
	@Override
	public int delete(Long id) {
		if (id == null || id <= 0) {
			return 0;
		}
		return this.configDao.deleteByPrimaryKey(id);
	}

	/**
	 * 根据ID更新操作
	 */
	@Override
	public int update(DatabaseConfigVo databaseConfigVo) {
		if (databaseConfigVo == null || databaseConfigVo.getId() == null) {
			return 0;
		}

		DatabaseConfig databaseConfig = this.getDatabaseConfig(databaseConfigVo);
		if (databaseConfig == null) {
			return 0;
		}

		return this.configDao.updateByPrimaryKeySelective(databaseConfig);
	}

	/**
	 * 根据ID查找操作
	 */
	@Override
	public DatabaseConfigVo findById(Long id) {
		if (id == null || id <= 0) {
			return null;
		}
		DatabaseConfig databaseConfig = this.configDao.selectByPrimaryKey(id);

		try {
			return (DatabaseConfigVo) ObjectCopyUtils.copyProperties(databaseConfig, DatabaseConfigVo.class);
		} catch (ReflectiveOperationException e) {
			logger.error("", e);
			return null;
		}
	}

	/**
	 * 分页查找接口
	 */
	@Override
	public PageInfo<DatabaseConfigVo> findByPage(DatabaseConfigVo databaseConfigVo, PageVo pageVo) {

		DatabaseConfig databaseConfig = this.getDatabaseConfig(databaseConfigVo);
		if (databaseConfig == null) {
			return null;
		}

		return this.findByPage(databaseConfig, pageVo.getPageNo(), pageVo.getPageSize(), pageVo.getOrderBy());
	}

	/**
	 * 分页查找
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private PageInfo<DatabaseConfigVo> findByPage(DatabaseConfig config, int pageNo, int pageSize, String orderBy) {
		PageHelper.startPage(pageNo, pageSize);
		if (orderBy != null && orderBy.length() > 0) {
			PageHelper.orderBy(orderBy);
		}

		Example example = ExampleUtils.getExampleFromObject(config);

		List<DatabaseConfig> list = this.configDao.selectByExample(example);

		try {
			PageInfo pageInfo = new PageInfo<>(list);
			pageInfo.setList(ObjectCopyUtils.copyPropertiesList(list, DatabaseConfigVo.class));
			return pageInfo;
		} catch (ReflectiveOperationException e) {
			logger.error("", e);
			return null;
		}
	}

	private DatabaseConfig getDatabaseConfig(DatabaseConfigVo databaseConfigVo) {
		try {
			return (DatabaseConfig) ObjectCopyUtils.copyProperties(databaseConfigVo, DatabaseConfig.class);
		} catch (ReflectiveOperationException e) {
			logger.error("", e);
			return null;
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<DatabaseConfigVo> findByList(DatabaseConfigVo databaseConfigVo) {
		
		DatabaseConfig databaseConfig = null;
		if(databaseConfigVo != null) {
			databaseConfig = this.getDatabaseConfig(databaseConfigVo);
			if (databaseConfig == null) {
				return Collections.emptyList();
			}
		}else {
			databaseConfig = new DatabaseConfig();
		}
		
		Example example = ExampleUtils.getExampleFromObject(databaseConfig);
		
		List<DatabaseConfig> list = this.configDao.selectByExample(example);
		
		try {
			return ObjectCopyUtils.copyPropertiesList(list, DatabaseConfigVo.class);
		} catch (ReflectiveOperationException e) {
			logger.error("", e);
			return Collections.emptyList();
		}
		
	}
}
