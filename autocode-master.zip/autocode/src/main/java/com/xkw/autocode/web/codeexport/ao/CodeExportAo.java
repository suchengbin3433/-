package com.xkw.autocode.web.codeexport.ao;

import java.util.List;

import com.xkw.autocode.jdbc.entity.TableEntity;

/**
 * “数据库配置表” Ao接口类
 * 
 * @author auto
 */
public interface CodeExportAo {

	public List<TableEntity> queryTables(Long databaseId);
	
	/**
	 * 查询表集合
	 * 
	 * @param databaseId
	 * @return
	 */
	public List<TableEntity> queryTables(Long databaseId, boolean queryColumn,String tableNames);

}
