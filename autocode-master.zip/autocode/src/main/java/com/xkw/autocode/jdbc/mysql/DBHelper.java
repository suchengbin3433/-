package com.xkw.autocode.jdbc.mysql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

//jdbc链接和执行工具类
public class DBHelper {

	private static final String DRIVER_NAME = "com.mysql.jdbc.Driver";

	private static final Logger logger = LoggerFactory.getLogger(DBHelper.class);

	private Connection conn = null;

	public DBHelper(String url, String username, String password) {
		try {
			// 指定连接类型
			Class.forName(DRIVER_NAME);

			// 获取连接
			conn = DriverManager.getConnection(url, username, password);
		} catch (Exception e) {
			logger.error("", e);
		}
	}

	public PreparedStatement getStatement(String sql) {
		PreparedStatement pst = null;
		try {
			// 准备执行语句
			pst = conn.prepareStatement(sql);
		} catch (SQLException e) {
			logger.error("", e);
		}
		return pst;
	}

	public void close() {
		try {
			this.conn.close();
		} catch (SQLException e) {
			logger.error("", e);
		}
	}
}
