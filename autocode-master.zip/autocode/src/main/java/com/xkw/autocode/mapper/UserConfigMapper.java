package com.xkw.autocode.mapper;

import com.xkw.autocode.base.BaseMapper;
import com.xkw.autocode.model.UserConfig;

/**
 * “用户配置表” Mapper 类
 * @author auto
*/
public interface UserConfigMapper extends BaseMapper<UserConfig>{
	
}
