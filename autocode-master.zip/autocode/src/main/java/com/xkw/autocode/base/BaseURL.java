package com.xkw.autocode.base;

import java.lang.reflect.Field;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BaseURL {

	private static final Logger logger = LoggerFactory.getLogger(BaseURL.class);

	protected static final String DYNAMIC_WEB_SUFFIX = ".htm";

	/**
	 * 根据url静态变量名取url值
	 * 
	 * @param urlName
	 * @return
	 */
	public String getURL(String urlName) {
		String url = "";

		try {
			Field f = this.getClass().getField(urlName);

			url = f.get(null).toString();
		} catch (Exception e) {
			logger.error("", e);
		}

		return url;
	}
}