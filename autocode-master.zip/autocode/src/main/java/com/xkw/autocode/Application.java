package com.xkw.autocode;

import java.net.InetAddress;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.embedded.EmbeddedServletContainerCustomizer;
import org.springframework.boot.web.servlet.ErrorPage;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.web.servlet.config.annotation.ContentNegotiationConfigurer;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.google.code.kaptcha.impl.DefaultKaptcha;
import com.google.code.kaptcha.util.Config;
import com.xkw.autocode.web.common.AuthInterceptor;

import tk.mybatis.spring.annotation.MapperScan;

@SpringBootApplication
@MapperScan("com.xkw.autocode.mapper")
public class Application extends WebMvcConfigurerAdapter {

	private static Logger logger = LoggerFactory.getLogger(Application.class);
	
	private static final String FOURZEROFOUR_STR = "/404.htm";
	
	@Autowired
	private AuthInterceptor authInterceptor;

	public static void main(String[] args) throws Exception{
		ConfigurableApplicationContext config = SpringApplication.run(Application.class, args);
		
		Environment env = config.getEnvironment();
		
		logger.info("\n-----------------------------------------------------------------------------------------\n" +
				"Application [{}] is running, The current  profiles is [{}] !\n" +
				"Remote Url: http://{}:{}{}/index.htm\n" +
				"Local Url: http://localhost:{}{}/index.htm\n" +
				"Dubbo address: {}\n" +
				
				"-----------------------------------------------------------------------------------------\n",
		env.getProperty("spring.application.name"),
		env.getProperty("spring.profiles.active"),
		InetAddress.getLocalHost().getHostAddress(),
		env.getProperty("server.port"),
		env.getProperty("server.contextPath"),
		env.getProperty("server.port"),
		env.getProperty("server.contextPath"),
		env.getProperty("spring.dubbo.registry.address"));
	}

	@Override
	public void configureContentNegotiation(ContentNegotiationConfigurer configurer) {
		// favorPathExtension表示支持后缀匹配
		configurer.favorPathExtension(false);
	}

	/**
	 *  自定义拦截器
	 */
	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		 registry.addInterceptor(authInterceptor).addPathPatterns("/**");
	}

	/**
	 *  定义错误页面
	 * @return
	 */
	@Bean
	public EmbeddedServletContainerCustomizer containerCustomizer() {

		return (container -> {
			ErrorPage error404Page = new ErrorPage(HttpStatus.NOT_FOUND, FOURZEROFOUR_STR);
			ErrorPage error500Page = new ErrorPage(HttpStatus.INTERNAL_SERVER_ERROR, FOURZEROFOUR_STR);
			container.addErrorPages(error404Page, error500Page);
		});
	}
	
    /**
     * 图片验证码设置
     * 参数设置参考：https://www.cnblogs.com/ljdblog/p/5844177.html
     * @return
     */
    @Bean
    public DefaultKaptcha producer() {
        Properties properties = new Properties();
        properties.put("kaptcha.border", "no");	//图片是否待边框
        properties.put("kaptcha.textproducer.char.length", "4");	//验证码长度
        properties.put("kaptcha.textproducer.font.color", "black");	//字体颜色
        properties.put("kaptcha.textproducer.char.space", "5");	//文字间隔
        Config config = new Config(properties);
        DefaultKaptcha defaultKaptcha = new DefaultKaptcha();
        defaultKaptcha.setConfig(config);
        return defaultKaptcha;
    }
}
