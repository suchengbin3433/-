package com.xkw.autocode.util;

import java.io.Serializable;

/**
 * 分页配置
*/
public class PageVo  implements Serializable{
	public static final Integer DEFAULT_PAGENO = 1;
	public static final Integer DEFAULT_PAGESIZE = 15;
	public static final Integer MAX_PAGESIZE = 100;

	private static final long serialVersionUID = 1L;

	private Integer pageNo;
	private Integer pageSize;
	private String orderBy;
	public PageVo() {
		super();
	}
	public PageVo(Integer pageNo, Integer pageSize, String orderBy) {
		super();
		this.pageNo = pageNo;
		this.pageSize = pageSize;
		this.orderBy = orderBy;
	}
	public Integer getPageNo() {
		if(pageNo == null){
			return DEFAULT_PAGENO;
		}
		return pageNo;
	}
	public void setPageNo(Integer pageNo) {
		this.pageNo = pageNo;
	}
	public Integer getPageSize() {
		if(pageSize == null){
			return DEFAULT_PAGESIZE;
		}
		return pageSize;
	}
	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}
	public String getOrderBy() {
		return orderBy;
	}
	public void setOrderBy(String orderBy) {
		this.orderBy = orderBy;
	}
}