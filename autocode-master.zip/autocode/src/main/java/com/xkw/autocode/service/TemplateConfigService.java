package com.xkw.autocode.service;

import java.util.List;

import com.xkw.autocode.vo.TemplateConfigVo;

/**
 * “模板配置表”	业务对内接口类
 * @author auto
*/
public interface TemplateConfigService{

	/**
	 * 新增接口
	 * @param templateConfigVo
	 * @return
	*/
	public int insert(TemplateConfigVo templateConfigVo);

	/**
	 * 根据ID删除接口
	 * @param id
	 * @return
	*/
	public int delete(Long id);

	/**
	 * 根据ID更新接口
	 * @param templateConfigVo
	 * @return
	*/
	public int update(TemplateConfigVo templateConfigVo);

	/**
	 * 根据ID查找接口
	 * @param id
	 * @return
	*/
	public TemplateConfigVo findById(Long id);
	
	/**
	 * 列表查询
	 * @param templateConfigVo
	 * @return
	 */
	public List<TemplateConfigVo> findByList(TemplateConfigVo templateConfigVo);

}

