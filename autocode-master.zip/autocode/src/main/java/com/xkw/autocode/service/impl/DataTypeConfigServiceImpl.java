package com.xkw.autocode.service.impl;

import java.util.Collections;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.xkw.autocode.mapper.DataTypeConfigMapper;
import com.xkw.autocode.model.DataTypeConfig;
import com.xkw.autocode.service.DataTypeConfigService;
import com.xkw.autocode.util.ExampleUtils;
import com.xkw.autocode.util.ObjectCopyUtils;
import com.xkw.autocode.util.PageVo;
import com.xkw.autocode.vo.DataTypeConfigVo;

import tk.mybatis.mapper.entity.Example;

/**
 * “数据库和java的类型映射配置” 业务类
 * 
 * @author auto
 */
@Service("dataTypeConfigService")
public class DataTypeConfigServiceImpl implements DataTypeConfigService {

	private static final Logger logger = LoggerFactory.getLogger(DatabaseConfigServiceImpl.class);

	@Autowired
	private DataTypeConfigMapper dataTypeConfigDao;

	/**
	 * 新增操作
	 */
	@Override
	public int insert(DataTypeConfigVo dataTypeConfigVo) {
		if (dataTypeConfigVo == null) {
			return 0;
		}
		DataTypeConfig dataTypeConfig = this.getDataTypeConfig(dataTypeConfigVo);
		if (dataTypeConfig == null) {
			return 0;
		}

		return this.dataTypeConfigDao.insertSelective(dataTypeConfig);
	}

	/**
	 * 根据ID删除操作
	 */
	@Override
	public int delete(Long id) {
		if (id == null || id <= 0) {
			return 0;
		}
		return this.dataTypeConfigDao.deleteByPrimaryKey(id);
	}

	/**
	 * 根据ID更新操作
	 */
	@Override
	public int update(DataTypeConfigVo dataTypeConfigVo) {
		if (dataTypeConfigVo == null || dataTypeConfigVo.getId() == null) {
			return 0;
		}

		DataTypeConfig dataTypeConfig = this.getDataTypeConfig(dataTypeConfigVo);
		if (dataTypeConfig == null) {
			return 0;
		}
		return this.dataTypeConfigDao.updateByPrimaryKeySelective(dataTypeConfig);
	}

	/**
	 * 根据ID查找操作
	 */
	@Override
	public DataTypeConfigVo findById(Long id) {
		if (id == null || id <= 0) {
			return null;
		}

		DataTypeConfig dataTypeConfig = this.dataTypeConfigDao.selectByPrimaryKey(id);

		try {
			return (DataTypeConfigVo) ObjectCopyUtils.copyProperties(dataTypeConfig, DataTypeConfigVo.class);
		} catch (ReflectiveOperationException e) {
			logger.error("", e);
			return null;
		}
	}

	/**
	 * 分页查找接口
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<DataTypeConfigVo> fintList(DataTypeConfigVo dataTypeConfigVo) {
		
		DataTypeConfig databaseConfig = this.getDataTypeConfig(dataTypeConfigVo);
		if(databaseConfig == null) {
			Collections.emptyList();
		}
		
		Example example = ExampleUtils.getExampleFromObject(databaseConfig);

		List<DataTypeConfig> list = this.dataTypeConfigDao.selectByExample(example);
		
		try {
			return (List<DataTypeConfigVo>) ObjectCopyUtils.copyPropertiesList(list, DataTypeConfigVo.class);
		} catch (ReflectiveOperationException e) {
			logger.error("", e);
			return Collections.emptyList();
		}
	}

	/**
	 * 分页查找接口
	 */
	@Override
	public PageInfo<DataTypeConfigVo> findByPage(DataTypeConfigVo dataTypeConfigVo, PageVo pageVo) {

		DataTypeConfig dataTypeConfig = this.getDataTypeConfig(dataTypeConfigVo);
		if (dataTypeConfig == null) {
			return null;
		}
		return this.findByPage(dataTypeConfig, pageVo.getPageNo(), pageVo.getPageSize(), pageVo.getOrderBy());
	}

	/**
	 * 分页查找
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private PageInfo<DataTypeConfigVo> findByPage(DataTypeConfig dataTypeConfig, int pageNo, int pageSize, String orderBy) {
		PageHelper.startPage(pageNo, pageSize);
		if (orderBy != null && orderBy.length() > 0) {
			PageHelper.orderBy(orderBy);
		}

		Example example = ExampleUtils.getExampleFromObject(dataTypeConfig);

		List<DataTypeConfig> list = this.dataTypeConfigDao.selectByExample(example);
		try {
			PageInfo pageInfo = new PageInfo<>(list);
			pageInfo.setList(ObjectCopyUtils.copyPropertiesList(list, DataTypeConfigVo.class));
			return pageInfo;
		} catch (ReflectiveOperationException e) {
			logger.error("", e);
			return null;
		}
	}
	
	private DataTypeConfig getDataTypeConfig(DataTypeConfigVo dataTypeConfigVo) {
		try {
			return (DataTypeConfig) ObjectCopyUtils.copyProperties(dataTypeConfigVo, DataTypeConfig.class);
		} catch (ReflectiveOperationException e) {
			logger.error("", e);
			return null;
		}
	}
}
